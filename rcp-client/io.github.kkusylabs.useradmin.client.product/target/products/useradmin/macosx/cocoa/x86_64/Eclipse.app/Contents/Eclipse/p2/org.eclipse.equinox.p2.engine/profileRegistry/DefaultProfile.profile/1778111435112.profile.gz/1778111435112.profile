<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1778111435112'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='C:\Users\kkusy\IdeaProjects\user-admin-system\rcp-client\io.github.kkusylabs.useradmin.client.product\target\products\useradmin\macosx\cocoa\x86_64\Eclipse.app\Contents\Eclipse'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=macosx,osgi.arch=x86_64,osgi.ws=cocoa,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='C:\Users\kkusy\IdeaProjects\user-admin-system\rcp-client\io.github.kkusylabs.useradmin.client.product\target\products\useradmin\macosx\cocoa\x86_64\Eclipse.app\Contents\Eclipse'/>
  </properties>
</profile>
