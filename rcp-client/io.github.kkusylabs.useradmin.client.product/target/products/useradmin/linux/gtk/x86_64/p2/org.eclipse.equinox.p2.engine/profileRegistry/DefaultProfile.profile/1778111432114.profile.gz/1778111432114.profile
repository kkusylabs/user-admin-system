<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1778111432114'>
  <properties size='6'>
    <property name='org.eclipse.equinox.p2.cache' value='C:\Users\kkusy\IdeaProjects\user-admin-system\rcp-client\io.github.kkusylabs.useradmin.client.product\target\products\useradmin\linux\gtk\x86_64'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='C:\Users\kkusy\IdeaProjects\user-admin-system\rcp-client\io.github.kkusylabs.useradmin.client.product\target\products\useradmin\linux\gtk\x86_64'/>
    <property name='eclipse.touchpoint.launcherName' value='eclipse'/>
  </properties>
  <units size='114'>
    <unit id='a.jre.javase' version='21.0.0' singleton='false'>
      <provides size='260'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' version='21.0.0'/>
        <provided namespace='java.package' name='java.applet' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.image' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.table' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.desktop' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.jpeg' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.type' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.dom' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.zip' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.views' version='0.0.0'/>
        <provided namespace='java.package' name='java.time' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.element' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.bootstrap' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.nio.sctp' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.validation' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.beans' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.net.httpserver' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.connect' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.events' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.foreign' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.datatransfer' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.event' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.metal' version='0.0.0'/>
        <provided namespace='java.package' name='java.net.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.logging' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.colorchooser' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.support' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.x500' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jfr' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.directory' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.chrono' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.loading' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='java.math' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction.xa' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.geom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stax' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.traversal' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.swing.interop' version='0.0.0'/>
        <provided namespace='java.package' name='java.text' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.undo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.datatype' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.html' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.connect.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.beans' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.event' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.prefs' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='java.net' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.bmp' version='0.0.0'/>
        <provided namespace='java.package' name='sun.misc' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.format' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.server' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.serial' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.synth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.basic' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.tree' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.function' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.linker' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.image.renderable' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.nio.file' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ls' version='0.0.0'/>
        <provided namespace='java.package' name='javax.smartcardio' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.random' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.linker.support' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.dgc' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation.processing' version='0.0.0'/>
        <provided namespace='java.package' name='java.net.http' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.invoke' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.catalog' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.nio' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.management' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent.atomic' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.event' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.color' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.openmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.rtf' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.javadoc.doclet' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.print' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.multi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.channels.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.events' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.registry' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.java.accessibility.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.management.jfr' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.constant' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.request' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.ref' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.instrument' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.regex' version='0.0.0'/>
        <provided namespace='java.package' name='org.ietf.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.filechooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.spec' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.reflect' version='0.0.0'/>
        <provided namespace='java.package' name='java.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap.spi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.attach' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute.standard' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.tool' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.jconsole' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.security.jarsigner' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.kerberos' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='java.sql' version='0.0.0'/>
        <provided namespace='java.package' name='java.util' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.channels' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.temporal' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.stylesheets' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.charset' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.net' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.monitor' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.doctree' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.net.httpserver.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.execution' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.im' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html.parser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.css' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.javac' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.charset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.text.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.timer' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.spec' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.keyinfo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.tree' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.font' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.attach.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.relation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.modelmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.sax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.event' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent.locks' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.nimbus' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.nio.mapmode' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.border' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jfr.consumer' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.tiff' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.ext' version='0.0.0'/>
        <provided namespace='java.package' name='sun.reflect' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.sasl' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.module' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.zone' version='0.0.0'/>
        <provided namespace='java.package' name='netscape.javascript' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.im.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.beans.beancontext' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.tools' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.script' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.module' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset' version='0.0.0'/>
        <provided namespace='java.package' name='java.io' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.jar' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ranges' version='0.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.1.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.3.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.4.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.5.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.6.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.7.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='9.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='10.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='11.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='12.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='13.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='14.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='15.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='16.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='17.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='18.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='19.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='20.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='21.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='21.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='21.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='21.0.0'/>
      </provides>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='com.github.weisj.jsvg' version='2.0.0' singleton='false' generation='2'>
      <update id='com.github.weisj.jsvg' range='[0.0.0,2.0.0)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='com.github.weisj.jsvg'/>
        <property name='maven-groupId' value='com.github.weisj'/>
        <property name='maven-artifactId' value='jsvg'/>
        <property name='maven-version' value='2.0.0'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.github.weisj.jsvg' version='2.0.0'/>
        <provided namespace='osgi.bundle' name='com.github.weisj.jsvg' version='2.0.0'/>
        <provided namespace='java.package' name='com.github.weisj.jsvg' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.github.weisj.jsvg.renderer,com.github.weisj.jsvg.renderer.animation,com.github.weisj.jsvg.renderer.output,com.github.weisj.jsvg.view,javax.swing' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.github.weisj.jsvg.paint' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.github.weisj.jsvg.renderer,com.github.weisj.jsvg.renderer.output' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.github.weisj.jsvg.parser' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.github.weisj.jsvg,com.github.weisj.jsvg.paint,com.github.weisj.jsvg.parser.css,com.github.weisj.jsvg.parser.resources,javax.xml.stream' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.github.weisj.jsvg.parser.css' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.github.weisj.jsvg.parser' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.github.weisj.jsvg.parser.resources' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.github.weisj.jsvg.parser,com.github.weisj.jsvg.renderer,com.github.weisj.jsvg.renderer.output,com.github.weisj.jsvg.view' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.github.weisj.jsvg.renderer' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.github.weisj.jsvg.paint,com.github.weisj.jsvg.renderer.animation,com.github.weisj.jsvg.renderer.output,com.github.weisj.jsvg.view' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.github.weisj.jsvg.renderer.animation' version='2.0.0'/>
        <provided namespace='java.package' name='com.github.weisj.jsvg.renderer.awt' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.github.weisj.jsvg.renderer' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.github.weisj.jsvg.renderer.output' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.github.weisj.jsvg.renderer' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.github.weisj.jsvg.ui' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.github.weisj.jsvg.renderer.animation' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.github.weisj.jsvg.view' version='2.0.0'/>
        <provided namespace='java.package' name='com.github.weisj.jsvg.provider' version='2.0.0'/>
        <provided namespace='osgi.identity' name='com.github.weisj.jsvg' version='2.0.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='28'>
        <required namespace='java.package' name='java.awt' range='0.0.0'/>
        <required namespace='java.package' name='java.awt.color' range='0.0.0'/>
        <required namespace='java.package' name='java.awt.event' range='0.0.0'/>
        <required namespace='java.package' name='java.awt.font' range='0.0.0'/>
        <required namespace='java.package' name='java.awt.geom' range='0.0.0'/>
        <required namespace='java.package' name='java.awt.image' range='0.0.0'/>
        <required namespace='java.package' name='java.io' range='0.0.0'/>
        <required namespace='java.package' name='java.lang' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.annotation' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.invoke' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.ref' range='0.0.0'/>
        <required namespace='java.package' name='java.net' range='0.0.0'/>
        <required namespace='java.package' name='java.nio.charset' range='0.0.0'/>
        <required namespace='java.package' name='java.text' range='0.0.0'/>
        <required namespace='java.package' name='java.util' range='0.0.0'/>
        <required namespace='java.package' name='java.util.function' range='0.0.0'/>
        <required namespace='java.package' name='java.util.logging' range='0.0.0'/>
        <required namespace='java.package' name='java.util.regex' range='0.0.0'/>
        <required namespace='java.package' name='java.util.stream' range='0.0.0'/>
        <required namespace='java.package' name='java.util.zip' range='0.0.0'/>
        <required namespace='java.package' name='javax.imageio' range='0.0.0'/>
        <required namespace='java.package' name='javax.imageio.stream' range='0.0.0'/>
        <required namespace='java.package' name='javax.swing' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.namespace' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.stream' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.stream.events' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            com.github.weisj.jsvg
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.github.weisj.jsvg.source' range='[2.0.0,2.0.0]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.github.weisj.jsvg' version='2.0.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.github.weisj.jsvg&#xA;Bundle-Version: 2.0.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.sun.jna' version='5.18.1.v20251001-0800' singleton='false' generation='2'>
      <update id='com.sun.jna' range='[0.0.0,5.18.1.v20251001-0800)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='jna'/>
        <property name='org.eclipse.equinox.p2.description' value='JNA Library'/>
        <property name='org.eclipse.equinox.p2.provider' value='JNA Development Team'/>
        <property name='maven-wrapped-groupId' value='net.java.dev.jna'/>
        <property name='maven-wrapped-artifactId' value='jna'/>
        <property name='maven-wrapped-version' value='5.18.1'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.sun.jna' version='5.18.1.v20251001-0800'/>
        <provided namespace='osgi.bundle' name='com.sun.jna' version='5.18.1.v20251001-0800'/>
        <provided namespace='java.package' name='com.sun.jna' version='5.18.1'/>
        <provided namespace='java.package' name='com.sun.jna.ptr' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.win32' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='com.sun.jna' version='5.18.1.v20251001-0800'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.6))'>
          <description>
            com.sun.jna
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.sun.jna.source' range='[5.18.1.v20251001-0800,5.18.1.v20251001-0800]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.sun.jna' version='5.18.1.v20251001-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.sun.jna&#xA;Bundle-Version: 5.18.1.v20251001-0800
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.sun.jna.platform' version='5.18.1' singleton='false' generation='2'>
      <update id='com.sun.jna.platform' range='[0.0.0,5.18.1)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='jna-platform'/>
        <property name='org.eclipse.equinox.p2.description' value='JNA Platform Library'/>
        <property name='org.eclipse.equinox.p2.provider' value='JNA Development Team'/>
        <property name='maven-groupId' value='net.java.dev.jna'/>
        <property name='maven-artifactId' value='jna-platform'/>
        <property name='maven-version' value='5.18.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='18'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.sun.jna.platform' version='5.18.1'/>
        <provided namespace='osgi.bundle' name='com.sun.jna.platform' version='5.18.1'/>
        <provided namespace='java.package' name='com.sun.jna.platform' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.platform.win32' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.dnd' version='5.18.1'/>
        <provided namespace='java.package' name='com.sun.jna.platform.linux' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.platform.unix' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.mac' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.platform,com.sun.jna.platform.unix,com.sun.jna.ptr' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.unix' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.ptr' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.unix.aix' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.unix.solaris' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.ptr' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.win32' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.platform,com.sun.jna.platform.win32.COM,com.sun.jna.ptr,com.sun.jna.win32' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.platform.win32,com.sun.jna.platform.win32.COM.util,com.sun.jna.ptr,com.sun.jna.win32' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM.tlb' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna.platform.win32.COM.tlb.imp' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM.tlb.imp' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna.platform.win32,com.sun.jna.platform.win32.COM' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM.util' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.platform.win32,com.sun.jna.platform.win32.COM,com.sun.jna.platform.win32.COM.util.annotation,com.sun.jna.ptr' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM.util.annotation' version='5.18.1'/>
        <provided namespace='java.package' name='com.sun.jna.platform.wince' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.platform.win32' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='com.sun.jna.platform' version='5.18.1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='com.sun.jna' range='5.18.1'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.4))'>
          <description>
            com.sun.jna.platform
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.sun.jna.platform.source' range='[5.18.1,5.18.1]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.sun.jna.platform' version='5.18.1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.sun.jna.platform&#xA;Bundle-Version: 5.18.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='io.github.kkusylabs.useradmin.client.branding' version='1.0.0.202605062350' generation='2'>
      <update id='io.github.kkusylabs.useradmin.client.branding' range='[0.0.0,1.0.0.202605062350)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Branding'/>
        <property name='maven-groupId' value='io.github.kkusylabs.useradmin'/>
        <property name='maven-artifactId' value='io.github.kkusylabs.useradmin.client.branding'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='io.github.kkusylabs.useradmin.client.branding' version='1.0.0.202605062350'/>
        <provided namespace='osgi.bundle' name='io.github.kkusylabs.useradmin.client.branding' version='1.0.0.202605062350'/>
        <provided namespace='osgi.identity' name='io.github.kkusylabs.useradmin.client.branding' version='1.0.0.202605062350'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.app' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            io.github.kkusylabs.useradmin.client.branding
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='io.github.kkusylabs.useradmin.client.branding.source' range='[1.0.0.202605062350,1.0.0.202605062350]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='io.github.kkusylabs.useradmin.client.branding' version='1.0.0.202605062350'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: io.github.kkusylabs.useradmin.client.branding;singleton:=true&#xA;Bundle-Version: 1.0.0.202605062350
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='io.github.kkusylabs.useradmin.client.core' version='1.0.0.202605062350' singleton='false' generation='2'>
      <update id='io.github.kkusylabs.useradmin.client.core' range='[0.0.0,1.0.0.202605062350)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Core'/>
        <property name='maven-groupId' value='io.github.kkusylabs.useradmin'/>
        <property name='maven-artifactId' value='io.github.kkusylabs.useradmin.client.core'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='io.github.kkusylabs.useradmin.client.core' version='1.0.0.202605062350'/>
        <provided namespace='osgi.bundle' name='io.github.kkusylabs.useradmin.client.core' version='1.0.0.202605062350'/>
        <provided namespace='osgi.identity' name='io.github.kkusylabs.useradmin.client.core' version='1.0.0.202605062350'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            io.github.kkusylabs.useradmin.client.core
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='io.github.kkusylabs.useradmin.client.core.source' range='[1.0.0.202605062350,1.0.0.202605062350]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='io.github.kkusylabs.useradmin.client.core' version='1.0.0.202605062350'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: io.github.kkusylabs.useradmin.client.core&#xA;Bundle-Version: 1.0.0.202605062350
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='io.github.kkusylabs.useradmin.client.feature.feature.group' version='1.0.0.202605062350' singleton='false'>
      <update id='io.github.kkusylabs.useradmin.client.feature.feature.group' range='[0.0.0,1.0.0.202605062350)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='[Enter Feature Description here.]'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.example.com/description'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='io.github.kkusylabs.useradmin'/>
        <property name='maven-artifactId' value='io.github.kkusylabs.useradmin.client.feature'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='io.github.kkusylabs.useradmin.client.feature.feature.group' version='1.0.0.202605062350'/>
      </provides>
      <requires size='4'>
        <required namespace='org.eclipse.equinox.p2.iu' name='io.github.kkusylabs.useradmin.client.branding' range='[1.0.0.202605062350,1.0.0.202605062350]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='io.github.kkusylabs.useradmin.client.ui' range='[1.0.0.202605062350,1.0.0.202605062350]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='io.github.kkusylabs.useradmin.client.core' range='[1.0.0.202605062350,1.0.0.202605062350]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='io.github.kkusylabs.useradmin.client.feature.feature.jar' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='io.github.kkusylabs.useradmin.client.feature.feature.jar' version='1.0.0.202605062350'>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='[Enter Feature Description here.]'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.example.com/description'/>
        <property name='maven-groupId' value='io.github.kkusylabs.useradmin'/>
        <property name='maven-artifactId' value='io.github.kkusylabs.useradmin.client.feature'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='io.github.kkusylabs.useradmin.client.feature.feature.jar' version='1.0.0.202605062350'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='io.github.kkusylabs.useradmin.client.feature' version='1.0.0.202605062350'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='io.github.kkusylabs.useradmin.client.feature' version='1.0.0.202605062350'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='io.github.kkusylabs.useradmin.client.ui' version='1.0.0.202605062350' singleton='false' generation='2'>
      <update id='io.github.kkusylabs.useradmin.client.ui' range='[0.0.0,1.0.0.202605062350)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Client'/>
        <property name='maven-groupId' value='io.github.kkusylabs.useradmin'/>
        <property name='maven-artifactId' value='io.github.kkusylabs.useradmin.client.ui'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='io.github.kkusylabs.useradmin.client.ui' version='1.0.0.202605062350'/>
        <provided namespace='osgi.bundle' name='io.github.kkusylabs.useradmin.client.ui' version='1.0.0.202605062350'/>
        <provided namespace='osgi.identity' name='io.github.kkusylabs.useradmin.client.ui' version='1.0.0.202605062350'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.model.workbench' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.services' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench.swt' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            io.github.kkusylabs.useradmin.client.ui
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='io.github.kkusylabs.useradmin.client.ui.source' range='[1.0.0.202605062350,1.0.0.202605062350]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='io.github.kkusylabs.useradmin.client.ui' version='1.0.0.202605062350'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: io.github.kkusylabs.useradmin.client.ui&#xA;Bundle-Version: 1.0.0.202605062350
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='jakarta.annotation-api' version='2.1.1' singleton='false' generation='2'>
      <update id='jakarta.annotation-api' range='[0.0.0,2.1.1)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Jakarta Annotations API'/>
        <property name='org.eclipse.equinox.p2.description' value='Jakarta Annotations API'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.eclipse.org'/>
        <property name='maven-groupId' value='jakarta.annotation'/>
        <property name='maven-artifactId' value='jakarta.annotation-api'/>
        <property name='maven-version' value='2.1.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='jakarta.annotation-api' version='2.1.1'/>
        <provided namespace='osgi.bundle' name='jakarta.annotation-api' version='2.1.1'/>
        <provided namespace='java.package' name='jakarta.annotation' version='2.1.1'/>
        <provided namespace='java.package' name='jakarta.annotation.security' version='2.1.1'/>
        <provided namespace='java.package' name='jakarta.annotation.sql' version='2.1.1'/>
        <provided namespace='osgi.identity' name='jakarta.annotation-api' version='2.1.1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            jakarta.annotation-api
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='jakarta.annotation-api.source' range='[2.1.1,2.1.1]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='jakarta.annotation-api' version='2.1.1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: jakarta.annotation-api&#xA;Bundle-Version: 2.1.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='jakarta.inject.jakarta.inject-api' version='2.0.1' singleton='false' generation='2'>
      <update id='jakarta.inject.jakarta.inject-api' range='[0.0.0,2.0.1)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Jakarta Dependency Injection'/>
        <property name='org.eclipse.equinox.p2.description' value='Jakarta Dependency Injection'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.eclipse.org'/>
        <property name='maven-groupId' value='jakarta.inject'/>
        <property name='maven-artifactId' value='jakarta.inject-api'/>
        <property name='maven-version' value='2.0.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='jakarta.inject.jakarta.inject-api' version='2.0.1'/>
        <provided namespace='osgi.bundle' name='jakarta.inject.jakarta.inject-api' version='2.0.1'/>
        <provided namespace='java.package' name='jakarta.inject' version='2.0.1'/>
        <provided namespace='osgi.identity' name='jakarta.inject.jakarta.inject-api' version='2.0.1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            jakarta.inject.jakarta.inject-api
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='jakarta.inject.jakarta.inject-api.source' range='[2.0.1,2.0.1]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='jakarta.inject.jakarta.inject-api' version='2.0.1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: jakarta.inject.jakarta.inject-api&#xA;Bundle-Version: 2.0.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.batik.constants' version='1.19.0.v20250506-1400' singleton='false' generation='2'>
      <update id='org.apache.batik.constants' range='[0.0.0,1.19.0.v20250506-1400)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Bundle org.apache.xmlgraphics : batik-constants'/>
        <property name='maven-wrapped-groupId' value='org.apache.xmlgraphics'/>
        <property name='maven-wrapped-artifactId' value='batik-constants'/>
        <property name='maven-wrapped-version' value='1.19'/>
        <property name='maven-wrapped-classifier' value=''/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.constants' version='1.19.0.v20250506-1400'/>
        <provided namespace='osgi.bundle' name='org.apache.batik.constants' version='1.19.0.v20250506-1400'/>
        <provided namespace='java.package' name='org.apache.batik.constants' version='1.19.0'/>
        <provided namespace='osgi.identity' name='org.apache.batik.constants' version='1.19.0.v20250506-1400'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='java.lang' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.apache.batik.constants
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.constants.source' range='[1.19.0.v20250506-1400,1.19.0.v20250506-1400]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.batik.constants' version='1.19.0.v20250506-1400'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.batik.constants&#xA;Bundle-Version: 1.19.0.v20250506-1400
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.batik.css' version='1.19.0.v20250506-1400' singleton='false' generation='2'>
      <update id='org.apache.batik.css' range='[0.0.0,1.19.0.v20250506-1400)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Bundle org.apache.xmlgraphics : batik-css'/>
        <property name='maven-wrapped-groupId' value='org.apache.xmlgraphics'/>
        <property name='maven-wrapped-artifactId' value='batik-css'/>
        <property name='maven-wrapped-version' value='1.19'/>
        <property name='maven-wrapped-classifier' value=''/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.css' version='1.19.0.v20250506-1400'/>
        <provided namespace='osgi.bundle' name='org.apache.batik.css' version='1.19.0.v20250506-1400'/>
        <provided namespace='java.package' name='org.apache.batik.css.dom' version='1.19.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.batik.css.engine,org.apache.batik.css.engine.value,org.w3c.dom,org.w3c.dom.css,org.w3c.dom.svg,org.w3c.dom.views' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.batik.css.engine' version='1.19.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.batik.css.engine.sac,org.apache.batik.css.engine.value,org.apache.batik.css.parser,org.apache.batik.i18n,org.apache.batik.util,org.w3c.css.sac,org.w3c.dom,org.w3c.dom.events' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.batik.css.engine.resources' version='1.19.0'/>
        <provided namespace='java.package' name='org.apache.batik.css.engine.sac' version='1.19.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.w3c.css.sac,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.batik.css.engine.value' version='1.19.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.batik.css.engine,org.apache.batik.i18n,org.apache.batik.util,org.w3c.css.sac,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.batik.css.engine.value.css2' version='1.19.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.batik.css.engine,org.apache.batik.css.engine.value,org.w3c.css.sac,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.batik.css.engine.value.resources' version='1.19.0'/>
        <provided namespace='java.package' name='org.apache.batik.css.engine.value.svg' version='1.19.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.batik.css.engine,org.apache.batik.css.engine.value,org.w3c.css.sac,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.batik.css.engine.value.svg12' version='1.19.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.batik.css.engine,org.apache.batik.css.engine.value,org.apache.batik.css.engine.value.svg,org.w3c.css.sac,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.batik.css.parser' version='1.19.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.batik.i18n,org.apache.batik.util.io,org.w3c.css.sac' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.batik.css.parser.resources' version='1.19.0'/>
        <provided namespace='osgi.identity' name='org.apache.batik.css' version='1.19.0.v20250506-1400'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='java.package' name='org.w3c.dom.svg' range='1.1.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom.css' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom.events' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom.views' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.java2d.color' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='java.awt' range='0.0.0'/>
        <required namespace='java.package' name='java.io' range='0.0.0'/>
        <required namespace='java.package' name='java.lang' range='0.0.0'/>
        <required namespace='java.package' name='java.util' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.batik.i18n' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.batik.util' range='[1.19.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.batik.util.io' range='[1.19.0,2.0.0)'/>
        <required namespace='java.package' name='org.w3c.css.sac' range='[1.3.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.apache.batik.css
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.css.source' range='[1.19.0.v20250506-1400,1.19.0.v20250506-1400]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.batik.css' version='1.19.0.v20250506-1400'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.batik.css&#xA;Bundle-Version: 1.19.0.v20250506-1400
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.batik.i18n' version='1.19.0.v20250506-1400' singleton='false' generation='2'>
      <update id='org.apache.batik.i18n' range='[0.0.0,1.19.0.v20250506-1400)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Bundle org.apache.xmlgraphics : batik-i18n'/>
        <property name='maven-wrapped-groupId' value='org.apache.xmlgraphics'/>
        <property name='maven-wrapped-artifactId' value='batik-i18n'/>
        <property name='maven-wrapped-version' value='1.19'/>
        <property name='maven-wrapped-classifier' value=''/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.i18n' version='1.19.0.v20250506-1400'/>
        <provided namespace='osgi.bundle' name='org.apache.batik.i18n' version='1.19.0.v20250506-1400'/>
        <provided namespace='java.package' name='org.apache.batik.i18n' version='1.19.0'/>
        <provided namespace='osgi.identity' name='org.apache.batik.i18n' version='1.19.0.v20250506-1400'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='java.package' name='java.lang' range='0.0.0'/>
        <required namespace='java.package' name='java.text' range='0.0.0'/>
        <required namespace='java.package' name='java.util' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.apache.batik.i18n
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.i18n.source' range='[1.19.0.v20250506-1400,1.19.0.v20250506-1400]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.batik.i18n' version='1.19.0.v20250506-1400'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.batik.i18n&#xA;Bundle-Version: 1.19.0.v20250506-1400
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.batik.util' version='1.19.0.v20250506-1400' singleton='false' generation='2'>
      <update id='org.apache.batik.util' range='[0.0.0,1.19.0.v20250506-1400)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Bundle org.apache.xmlgraphics : batik-util'/>
        <property name='maven-wrapped-groupId' value='org.apache.xmlgraphics'/>
        <property name='maven-wrapped-artifactId' value='batik-util'/>
        <property name='maven-wrapped-version' value='1.19'/>
        <property name='maven-wrapped-classifier' value=''/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.util' version='1.19.0.v20250506-1400'/>
        <provided namespace='osgi.bundle' name='org.apache.batik.util' version='1.19.0.v20250506-1400'/>
        <provided namespace='java.package' name='org.apache.batik' version='1.19.0'/>
        <provided namespace='java.package' name='org.apache.batik.util' version='1.19.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.batik.constants,org.apache.batik.i18n,org.apache.batik.util.resources' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.batik.util.io' version='1.19.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.batik.i18n' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.batik.util.io.resources' version='1.19.0'/>
        <provided namespace='java.package' name='org.apache.batik.util.resources' version='1.19.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.batik.i18n' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.apache.batik.util' version='1.19.0.v20250506-1400'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='java.package' name='java.awt' range='0.0.0'/>
        <required namespace='java.package' name='java.io' range='0.0.0'/>
        <required namespace='java.package' name='java.lang' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.ref' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.reflect' range='0.0.0'/>
        <required namespace='java.package' name='java.net' range='0.0.0'/>
        <required namespace='java.package' name='java.security' range='0.0.0'/>
        <required namespace='java.package' name='java.util' range='0.0.0'/>
        <required namespace='java.package' name='java.util.jar' range='0.0.0'/>
        <required namespace='java.package' name='java.util.zip' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.batik.constants' range='[1.19.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.batik.i18n' range='[1.19.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.apache.batik.util
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.util.source' range='[1.19.0.v20250506-1400,1.19.0.v20250506-1400]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.batik.util' version='1.19.0.v20250506-1400'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.batik.util&#xA;Bundle-Version: 1.19.0.v20250506-1400
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.commons-io' version='2.21.0' singleton='false' generation='2'>
      <update id='org.apache.commons.commons-io' range='[0.0.0,2.21.0)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Commons IO'/>
        <property name='org.eclipse.equinox.p2.description' value='The Apache Commons IO library contains utility classes, stream implementations, file filters,file comparators, endian transformation classes, and much more.'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://commons.apache.org/proper/commons-io/'/>
        <property name='maven-groupId' value='commons-io'/>
        <property name='maven-artifactId' value='commons-io'/>
        <property name='maven-version' value='2.21.0'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='24'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.commons-io' version='2.21.0'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.commons-io' version='2.21.0'/>
        <provided namespace='java.package' name='org.apache.commons.io' version='1.4.9999'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.commons.io.filefilter,org.apache.commons.io.function,org.apache.commons.io.input' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.commons.io.comparator' version='1.4.9999'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.commons.io' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.commons.io.filefilter' version='1.4.9999'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.commons.io,org.apache.commons.io.build,org.apache.commons.io.file' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.commons.io.input' version='1.4.9999'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.commons.io,org.apache.commons.io.build,org.apache.commons.io.function,org.apache.commons.io.output' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.commons.io.output' version='1.4.9999'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.commons.io.build,org.apache.commons.io.function,org.apache.commons.io.input' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.commons.io.build' version='2.21.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.commons.io,org.apache.commons.io.function' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.commons.io.channels' version='2.21.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.charset' version='2.21.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.file' version='2.21.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.commons.io.build,org.apache.commons.io.function' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.commons.io.file.attribute' version='2.21.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.file.spi' version='2.21.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.function' version='2.21.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.commons.io' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.commons.io.input.buffer' version='2.21.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.monitor' version='2.21.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.commons.io,org.apache.commons.io.build' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.commons.io.serialization' version='2.21.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.commons.io.build' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.commons.io' version='2.21.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.comparator' version='2.21.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.filefilter' version='2.21.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.input' version='2.21.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.output' version='2.21.0'/>
        <provided namespace='osgi.identity' name='org.apache.commons.commons-io' version='2.21.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='30'>
        <required namespace='java.package' name='sun.nio.ch' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='sun.misc' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.io' range='0.0.0'/>
        <required namespace='java.package' name='java.lang' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.invoke' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.ref' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.reflect' range='0.0.0'/>
        <required namespace='java.package' name='java.math' range='0.0.0'/>
        <required namespace='java.package' name='java.net' range='0.0.0'/>
        <required namespace='java.package' name='java.nio' range='0.0.0'/>
        <required namespace='java.package' name='java.nio.channels' range='0.0.0'/>
        <required namespace='java.package' name='java.nio.charset' range='0.0.0'/>
        <required namespace='java.package' name='java.nio.file' range='0.0.0'/>
        <required namespace='java.package' name='java.nio.file.attribute' range='0.0.0'/>
        <required namespace='java.package' name='java.nio.file.spi' range='0.0.0'/>
        <required namespace='java.package' name='java.security' range='0.0.0'/>
        <required namespace='java.package' name='java.text' range='0.0.0'/>
        <required namespace='java.package' name='java.time' range='0.0.0'/>
        <required namespace='java.package' name='java.time.chrono' range='0.0.0'/>
        <required namespace='java.package' name='java.time.temporal' range='0.0.0'/>
        <required namespace='java.package' name='java.util' range='0.0.0'/>
        <required namespace='java.package' name='java.util.concurrent' range='0.0.0'/>
        <required namespace='java.package' name='java.util.concurrent.atomic' range='0.0.0'/>
        <required namespace='java.package' name='java.util.concurrent.locks' range='0.0.0'/>
        <required namespace='java.package' name='java.util.function' range='0.0.0'/>
        <required namespace='java.package' name='java.util.regex' range='0.0.0'/>
        <required namespace='java.package' name='java.util.stream' range='0.0.0'/>
        <required namespace='java.package' name='java.util.zip' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.apache.commons.commons-io
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.commons-io.source' range='[2.21.0,2.21.0]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.commons-io' version='2.21.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.commons-io&#xA;Bundle-Version: 2.21.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.commons-logging' version='1.3.5' singleton='false' generation='2'>
      <update id='org.apache.commons.commons-logging' range='[0.0.0,1.3.5)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Commons Logging'/>
        <property name='org.eclipse.equinox.p2.description' value='Apache Commons Logging is a thin adapter allowing configurable bridging to other,    well-known logging systems.'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://commons.apache.org/proper/commons-logging/'/>
        <property name='maven-groupId' value='commons-logging'/>
        <property name='maven-artifactId' value='commons-logging'/>
        <property name='maven-version' value='1.3.5'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.commons-logging' version='1.3.5'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.commons-logging' version='1.3.5'/>
        <provided namespace='java.package' name='org.apache.commons.logging' version='1.3.5'/>
        <provided namespace='java.package' name='org.apache.commons.logging.impl' version='1.3.5'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.servlet,org.apache.avalon.framework.logger,org.apache.commons.logging,org.apache.log,org.apache.log4j' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.apache.commons.commons-logging' version='1.3.5'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='java.package' name='javax.servlet' range='[2.1.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.avalon.framework.logger' range='[4.1.3,4.1.5]' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.log' range='[1.0.1,1.0.1]' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.log4j' range='[1.2.15,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j' range='[2.0.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.spi' range='[2.0.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.util' range='[2.0.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.slf4j' range='[1.7.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.slf4j.spi' range='[1.7.0,3.0.0)' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.serviceloader.processor)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))' min='0' greedy='false'>
          <description>
            org.apache.commons.commons-logging
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.serviceloader' match='(osgi.serviceloader=org.apache.commons.logging.LogFactory)' min='0' greedy='false'>
          <description>
            org.apache.commons.commons-logging
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.apache.commons.commons-logging
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.commons-logging.source' range='[1.3.5,1.3.5]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.commons-logging' version='1.3.5'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.commons-logging&#xA;Bundle-Version: 1.3.5
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.gogo.command' version='1.1.2' singleton='false' generation='2'>
      <update id='org.apache.felix.gogo.command' range='[0.0.0,1.1.2)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Felix Gogo Command'/>
        <property name='org.eclipse.equinox.p2.description' value='Provides basic shell commands for Gogo.'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.apache.org/'/>
        <property name='maven-groupId' value='org.apache.felix'/>
        <property name='maven-artifactId' value='org.apache.felix.gogo.command'/>
        <property name='maven-version' value='1.1.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.command' version='1.1.2'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.gogo.command' version='1.1.2'/>
        <provided namespace='java.package' name='org.apache.felix.gogo.command' version='1.1.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.felix.service.command,org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.apache.felix.gogo.command' version='1.1.2'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.apache.felix.gogo' name='command.implementation' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='java.package' name='org.apache.felix.service.command' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='[1.2.0,2.0.0)'/>
        <requiredProperties namespace='org.apache.felix.gogo' match='(&amp;(org.apache.felix.gogo=runtime.implementation)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))'>
          <description>
            org.apache.felix.gogo.command
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.apache.felix.gogo.command
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.command.source' range='[1.1.2,1.1.2]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.gogo.command' version='1.1.2'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.gogo.command&#xA;Bundle-Version: 1.1.2
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.gogo.runtime' version='1.1.6' singleton='false' generation='2'>
      <update id='org.apache.felix.gogo.runtime' range='[0.0.0,1.1.6)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Felix Gogo Runtime'/>
        <property name='org.eclipse.equinox.p2.description' value='Apache Felix Gogo Subproject'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.apache.org/'/>
        <property name='maven-groupId' value='org.apache.felix'/>
        <property name='maven-artifactId' value='org.apache.felix.gogo.runtime'/>
        <property name='maven-version' value='1.1.6'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.runtime' version='1.1.6'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.gogo.runtime' version='1.1.6'/>
        <provided namespace='java.package' name='org.apache.felix.gogo.runtime' version='1.1.6'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.felix.service.command,org.apache.felix.service.threadio,org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.felix.gogo.runtime.activator' version='1.1.6'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.felix.gogo.runtime,org.apache.felix.service.command,org.apache.felix.service.threadio,org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.felix.gogo.runtime.threadio' version='1.1.6'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.felix.service.threadio' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.felix.service.command' version='1.0.0'/>
        <provided namespace='java.package' name='org.apache.felix.service.command.annotations' version='1.0.0'/>
        <provided namespace='java.package' name='org.apache.felix.service.threadio' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.apache.felix.gogo.runtime' version='1.1.6'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.apache.felix.gogo' name='runtime.implementation' version='1.0.0'/>
        <provided namespace='osgi.service' name='org.apache.felix.gogo.runtime_1.1.6-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.apache.felix.service.command.CommandProcessor'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.apache.felix.gogo.runtime_1.1.6-3' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.apache.felix.service.threadio.ThreadIO'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.felix.gogo.runtime.threadio' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.felix.service.command' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.felix.service.threadio' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='org.apache.felix.gogo' match='(&amp;(org.apache.felix.gogo=shell.implementation)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))'>
          <description>
            org.apache.felix.gogo.runtime
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.apache.felix.gogo.runtime
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.runtime.source' range='[1.1.6,1.1.6]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.gogo.runtime' version='1.1.6'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.gogo.runtime&#xA;Bundle-Version: 1.1.6
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.gogo.shell' version='1.1.4' singleton='false' generation='2'>
      <update id='org.apache.felix.gogo.shell' range='[0.0.0,1.1.4)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Felix Gogo Shell'/>
        <property name='org.eclipse.equinox.p2.description' value='Apache Felix Gogo Subproject'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.apache.org/'/>
        <property name='maven-groupId' value='org.apache.felix'/>
        <property name='maven-artifactId' value='org.apache.felix.gogo.shell'/>
        <property name='maven-version' value='1.1.4'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.shell' version='1.1.4'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.gogo.shell' version='1.1.4'/>
        <provided namespace='osgi.identity' name='org.apache.felix.gogo.shell' version='1.1.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.apache.felix.gogo' name='shell.implementation' version='1.0.0'>
          <properties size='1'>
            <property name='implementation.name' value='gogo.shell'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='java.package' name='org.apache.felix.service.command' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='org.apache.felix.gogo' match='(&amp;(org.apache.felix.gogo=command.implementation)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))'>
          <description>
            org.apache.felix.gogo.shell
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.apache.felix.gogo.shell
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.shell.source' range='[1.1.4,1.1.4]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.gogo.shell' version='1.1.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.gogo.shell&#xA;Bundle-Version: 1.1.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.scr' version='2.2.14' singleton='false' generation='2'>
      <update id='org.apache.felix.scr' range='[0.0.0,2.2.14)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Felix Declarative Services'/>
        <property name='org.eclipse.equinox.p2.description' value='Implementation of the Declarative Services specification 1.5'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://felix.apache.org/site/apache-felix-service-component-runtime.html'/>
        <property name='maven-groupId' value='org.apache.felix'/>
        <property name='maven-artifactId' value='org.apache.felix.scr'/>
        <property name='maven-version' value='2.2.14'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr' version='2.2.14'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.scr' version='2.2.14'/>
        <provided namespace='java.package' name='org.apache.felix.scr.component' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.service.component' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.felix.scr.info' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.apache.felix.scr' version='2.2.14'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.extender' name='osgi.component' version='1.5.0'/>
        <provided namespace='osgi.service' name='org.apache.felix.scr_2.2.14-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.component.runtime.ServiceComponentRuntime' type='List'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='22'>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.6.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.4.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.metatype' range='[1.2.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.felix.service.command' range='[1.0.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.felix.scr.component' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.apache.felix.scr.info' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.dto' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.10.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.resource' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.component' range='[1.5.0,1.6.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime' range='[1.5.0,1.6.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(|(&amp;(osgi.ee=JavaSE)(version=1.7))(&amp;(osgi.ee=JavaSE/compact1)(version=1.8)))'>
          <description>
            org.apache.felix.scr
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr.source' range='[2.2.14,2.2.14]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.scr' version='2.2.14'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.scr&#xA;Bundle-Version: 2.2.14
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.xmlgraphics' version='2.11.0.v20250506-1400' singleton='false' generation='2'>
      <update id='org.apache.xmlgraphics' range='[0.0.0,2.11.0.v20250506-1400)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Bundle org.apache.xmlgraphics : xmlgraphics-commons'/>
        <property name='maven-wrapped-groupId' value='org.apache.xmlgraphics'/>
        <property name='maven-wrapped-artifactId' value='xmlgraphics-commons'/>
        <property name='maven-wrapped-version' value='2.11'/>
        <property name='maven-wrapped-classifier' value=''/>
      </properties>
      <provides size='39'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.xmlgraphics' version='2.11.0.v20250506-1400'/>
        <provided namespace='osgi.bundle' name='org.apache.xmlgraphics' version='2.11.0.v20250506-1400'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.fonts' version='2.11.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.xmlgraphics.image.rendered' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.codec' version='2.11.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.codec.png' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.imageio.stream,org.apache.commons.logging,org.apache.xmlgraphics.image.codec.util,org.apache.xmlgraphics.image.loader,org.apache.xmlgraphics.image.rendered' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.codec.tiff' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.xmlgraphics.image.codec.util,org.apache.xmlgraphics.image.rendered' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.codec.util' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.imageio.stream' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.loader' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.imageio.stream,javax.xml.transform,org.apache.commons.logging,org.apache.xmlgraphics.image.loader.cache,org.apache.xmlgraphics.image.loader.pipeline,org.apache.xmlgraphics.image.loader.spi' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.loader.cache' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.commons.logging,org.apache.xmlgraphics.image.loader' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.loader.impl' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.imageio.stream,javax.xml.transform,org.apache.commons.logging,org.apache.xmlgraphics.image.loader,org.apache.xmlgraphics.image.loader.spi,org.apache.xmlgraphics.java2d,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.loader.impl.imageio' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.imageio.metadata,javax.xml.transform,org.apache.commons.logging,org.apache.xmlgraphics.image.loader,org.apache.xmlgraphics.image.loader.impl,org.apache.xmlgraphics.image.loader.spi,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.loader.pipeline' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.commons.logging,org.apache.xmlgraphics.image.loader,org.apache.xmlgraphics.image.loader.cache,org.apache.xmlgraphics.image.loader.spi,org.apache.xmlgraphics.image.loader.util,org.apache.xmlgraphics.util.dijkstra' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.loader.spi' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.transform,org.apache.commons.logging,org.apache.xmlgraphics.image.loader,org.apache.xmlgraphics.image.loader.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.loader.util' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.imageio.stream,javax.xml.transform,org.apache.xmlgraphics.image.codec.util,org.apache.xmlgraphics.image.loader' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.rendered' version='2.11.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.writer' version='2.11.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.writer.imageio' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.imageio,javax.imageio.event,javax.imageio.metadata,org.apache.xmlgraphics.image.writer,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.writer.internal' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.xmlgraphics.image.writer' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.io' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.transform' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.java2d' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.xmlgraphics.ps' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.java2d.color' version='2.11.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.java2d.color.profile' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.xmlgraphics.java2d.color' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.java2d.ps' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.xmlgraphics.java2d,org.apache.xmlgraphics.ps' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.ps' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.transform,org.apache.xmlgraphics.ps.dsc' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.ps.dsc' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.xmlgraphics.ps,org.apache.xmlgraphics.ps.dsc.events' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.ps.dsc.events' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.xmlgraphics.ps,org.apache.xmlgraphics.ps.dsc' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.ps.dsc.tools' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.xmlgraphics.ps,org.apache.xmlgraphics.ps.dsc,org.apache.xmlgraphics.ps.dsc.events' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.util' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.imageio.metadata,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.util.dijkstra' version='2.11.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.util.i18n' version='2.11.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.util.io' version='2.11.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.util.uri' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.transform' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.xmp' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.transform,org.apache.xmlgraphics.util,org.apache.xmlgraphics.xmp.merge,org.xml.sax,org.xml.sax.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.xmp.merge' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.xmlgraphics.util,org.apache.xmlgraphics.xmp' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.xmp.schemas' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.xmlgraphics.util,org.apache.xmlgraphics.xmp,org.apache.xmlgraphics.xmp.merge' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.xmlgraphics.xmp.schemas.pdf' version='2.11.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.xmlgraphics.xmp,org.apache.xmlgraphics.xmp.merge' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.apache.xmlgraphics' version='2.11.0.v20250506-1400'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='66'>
        <required namespace='java.package' name='java.awt' range='0.0.0'/>
        <required namespace='java.package' name='java.awt.color' range='0.0.0'/>
        <required namespace='java.package' name='java.awt.font' range='0.0.0'/>
        <required namespace='java.package' name='java.awt.geom' range='0.0.0'/>
        <required namespace='java.package' name='java.awt.image' range='0.0.0'/>
        <required namespace='java.package' name='java.awt.image.renderable' range='0.0.0'/>
        <required namespace='java.package' name='java.io' range='0.0.0'/>
        <required namespace='java.package' name='java.lang' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.ref' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.reflect' range='0.0.0'/>
        <required namespace='java.package' name='java.net' range='0.0.0'/>
        <required namespace='java.package' name='java.nio' range='0.0.0'/>
        <required namespace='java.package' name='java.nio.charset' range='0.0.0'/>
        <required namespace='java.package' name='java.security' range='0.0.0'/>
        <required namespace='java.package' name='java.text' range='0.0.0'/>
        <required namespace='java.package' name='java.util' range='0.0.0'/>
        <required namespace='java.package' name='java.util.concurrent.atomic' range='0.0.0'/>
        <required namespace='java.package' name='java.util.jar' range='0.0.0'/>
        <required namespace='java.package' name='java.util.zip' range='0.0.0'/>
        <required namespace='java.package' name='javax.imageio' range='0.0.0'/>
        <required namespace='java.package' name='javax.imageio.event' range='0.0.0'/>
        <required namespace='java.package' name='javax.imageio.metadata' range='0.0.0'/>
        <required namespace='java.package' name='javax.imageio.plugins.jpeg' range='0.0.0'/>
        <required namespace='java.package' name='javax.imageio.spi' range='0.0.0'/>
        <required namespace='java.package' name='javax.imageio.stream' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.dom' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.sax' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.stream' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.commons.io' range='[1.4.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.commons.io.output' range='[1.4.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.commons.logging' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.fonts' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.codec.png' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.codec.tiff' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.codec.util' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.loader' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.loader.cache' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.loader.impl' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.loader.pipeline' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.loader.spi' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.loader.util' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.rendered' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.writer' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.io' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.java2d' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.java2d.color' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.java2d.color.profile' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.ps' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.ps.dsc' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.ps.dsc.events' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.ps.dsc.tools' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.util' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.util.dijkstra' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.util.i18n' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.util.io' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.xmp' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.xmp.merge' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.xmp.schemas' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.xmp.schemas.pdf' range='[2.11.0,3.0.0)'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.apache.xmlgraphics
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.xmlgraphics.source' range='[2.11.0.v20250506-1400,2.11.0.v20250506-1400]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.xmlgraphics' version='2.11.0.v20250506-1400'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.xmlgraphics&#xA;Bundle-Version: 2.11.0.v20250506-1400
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.commands' version='3.12.500.v20251103-0733' singleton='false' generation='2'>
      <update id='org.eclipse.core.commands' range='[0.0.0,3.12.500.v20251103-0733)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Commands'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.commands'/>
        <property name='maven-version' value='3.12.500-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' version='3.12.500.v20251103-0733'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.commands' version='3.12.500.v20251103-0733'/>
        <provided namespace='java.package' name='org.eclipse.core.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.common' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.internal.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.commands.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.commands.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.commands' version='3.12.500.v20251103-0733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.commands
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands.source' range='[3.12.500.v20251103-0733,3.12.500.v20251103-0733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.commands' version='3.12.500.v20251103-0733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.commands&#xA;Bundle-Version: 3.12.500.v20251103-0733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.contenttype' version='3.9.800.v20251105-1620' generation='2'>
      <update id='org.eclipse.core.contenttype' range='[0.0.0,3.9.800.v20251105-1620)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Content Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.contenttype'/>
        <property name='maven-version' value='3.9.800-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' version='3.9.800.v20251105-1620'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.contenttype' version='3.9.800.v20251105-1620'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.content' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.content' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.contenttype' version='3.9.800.v20251105-1620'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.13.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'>
          <description>
            org.eclipse.core.contenttype
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.contenttype
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype.source' range='[3.9.800.v20251105-1620,3.9.800.v20251105-1620]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.contenttype' version='3.9.800.v20251105-1620'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.contenttype; singleton:=true&#xA;Bundle-Version: 3.9.800.v20251105-1620
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.databinding' version='1.13.700.v20251023-1511' singleton='false' generation='2'>
      <update id='org.eclipse.core.databinding' range='[0.0.0,1.13.700.v20251023-1511)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='JFace Data Binding'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.databinding'/>
        <property name='maven-version' value='1.13.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding' version='1.13.700.v20251023-1511'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.databinding' version='1.13.700.v20251023-1511'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.bind' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.bind.steps' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.conversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.conversion.text' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.validation' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.conversion' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.validation' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.databinding' version='1.13.700.v20251023-1511'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.property' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.4.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.3,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.databinding
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.source' range='[1.13.700.v20251023-1511,1.13.700.v20251023-1511]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.databinding' version='1.13.700.v20251023-1511'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.databinding&#xA;Bundle-Version: 1.13.700.v20251023-1511
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.databinding.beans' version='1.10.500.v20250916-0941' singleton='false' generation='2'>
      <update id='org.eclipse.core.databinding.beans' range='[0.0.0,1.10.500.v20250916-0941)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='JFace Data Binding for JavaBeans'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.databinding.beans'/>
        <property name='maven-version' value='1.10.500-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.beans' version='1.10.500.v20250916-0941'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.databinding.beans' version='1.10.500.v20250916-0941'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.beans' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.beans.typed' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.beans' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.databinding.beans' version='1.10.500.v20250916-0941'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.property' range='[1.3.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.databinding.beans
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.beans.source' range='[1.10.500.v20250916-0941,1.10.500.v20250916-0941]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.databinding.beans' version='1.10.500.v20250916-0941'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.databinding.beans&#xA;Bundle-Version: 1.10.500.v20250916-0941
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.databinding.observable' version='1.13.500.v20251103-0735' singleton='false' generation='2'>
      <update id='org.eclipse.core.databinding.observable' range='[0.0.0,1.13.500.v20251103-0735)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='JFace Data Binding Observables'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.databinding.observable'/>
        <property name='maven-version' value='1.13.500-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable' version='1.13.500.v20251103-0735'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' version='1.13.500.v20251103-0735'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.list' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.map' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.masterdetail' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.set' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.sideeffect' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.value' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.util' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.identity' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.observable' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.observable.masterdetail' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.observable.sideeffect' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.databinding.observable' version='1.13.500.v20251103-0735'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.8.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.databinding.observable
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable.source' range='[1.13.500.v20251103-0735,1.13.500.v20251103-0735]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.databinding.observable' version='1.13.500.v20251103-0735'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.databinding.observable&#xA;Bundle-Version: 1.13.500.v20251103-0735
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.databinding.property' version='1.10.500.v20250916-0931' singleton='false' generation='2'>
      <update id='org.eclipse.core.databinding.property' range='[0.0.0,1.10.500.v20250916-0931)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='JFace Data Binding Properties'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.databinding.property'/>
        <property name='maven-version' value='1.10.500-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property' version='1.10.500.v20250916-0931'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.databinding.property' version='1.10.500.v20250916-0931'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.list' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.map' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.set' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.value' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.list' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.set' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.value' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.databinding.property' version='1.10.500.v20250916-0931'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.3.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.databinding.property
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property.source' range='[1.10.500.v20250916-0931,1.10.500.v20250916-0931]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.databinding.property' version='1.10.500.v20250916-0931'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.databinding.property&#xA;Bundle-Version: 1.10.500.v20250916-0931
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.expressions' version='3.9.500.v20250608-0434' generation='2'>
      <update id='org.eclipse.core.expressions' range='[0.0.0,3.9.500.v20250608-0434)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Expression Language'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.expressions'/>
        <property name='maven-version' value='3.9.500-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' version='3.9.500.v20250608-0434'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.expressions' version='3.9.500.v20250608-0434'/>
        <provided namespace='java.package' name='org.eclipse.core.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions.propertytester' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.expressions' version='3.9.500.v20250608-0434'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.expressions
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions.source' range='[3.9.500.v20250608-0434,3.9.500.v20250608-0434]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.expressions' version='3.9.500.v20250608-0434'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.expressions; singleton:=true&#xA;Bundle-Version: 3.9.500.v20250608-0434
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.jobs' version='3.15.700.v20250725-1147' generation='2'>
      <update id='org.eclipse.core.jobs' range='[0.0.0,3.15.700.v20250725-1147)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Jobs Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.jobs'/>
        <property name='maven-version' value='3.15.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' version='3.15.700.v20250725-1147'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.jobs' version='3.15.700.v20250725-1147'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.jobs' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.jobs' version='3.15.700.v20250725-1147'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.8.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.jobs
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs.source' range='[3.15.700.v20250725-1147,3.15.700.v20250725-1147]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.jobs' version='3.15.700.v20250725-1147'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.jobs; singleton:=true&#xA;Bundle-Version: 3.15.700.v20250725-1147
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.runtime' version='3.34.200.v20251220-0953' generation='2'>
      <update id='org.eclipse.core.runtime' range='[0.0.0,3.34.200.v20251220-0953)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Core Runtime'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.runtime'/>
        <property name='maven-version' value='3.34.200-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' version='3.34.200.v20251220-0953'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.runtime' version='3.34.200.v20251220-0953'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.legacy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.7.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.runtime' version='3.34.200.v20251220-0953'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.23.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.20.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.15.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.12.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.12.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.contenttype' range='[3.9.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.app' range='1.7.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.runtime
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.source' range='[3.34.200.v20251220-0953,3.34.200.v20251220-0953]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.runtime' version='3.34.200.v20251220-0953'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.runtime; singleton:=true&#xA;Bundle-Version: 3.34.200.v20251220-0953
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.core.commands' version='1.1.700.v20250916-0927' generation='2'>
      <update id='org.eclipse.e4.core.commands' range='[0.0.0,1.1.700.v20250916-0927)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse e4 core commands'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.commands'/>
        <property name='maven-version' value='1.1.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands' version='1.1.700.v20250916-0927'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.core.commands' version='1.1.700.v20250916-0927'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.commands.internal' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.core.commands' version='1.1.700.v20250916-0927'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='0.9.0'/>
        <required namespace='java.package' name='jakarta.annotation' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.core.commands' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.commands.common' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.expressions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.contexts' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.e4.core.services.log' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.e4.core.commands
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands.source' range='[1.1.700.v20250916-0927,1.1.700.v20250916-0927]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.core.commands' version='1.1.700.v20250916-0927'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.core.commands;singleton:=true&#xA;Bundle-Version: 1.1.700.v20250916-0927
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.core.contexts' version='1.13.200.v20250609-0437' singleton='false' generation='2'>
      <update id='org.eclipse.e4.core.contexts' range='[0.0.0,1.13.200.v20250609-0437)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Contexts'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.contexts'/>
        <property name='maven-version' value='1.13.200-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.contexts' version='1.13.200.v20250609-0437'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' version='1.13.200.v20250609-0437'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.contexts' version='1.7.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.internal.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.internal.contexts.osgi' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.core.contexts' version='1.13.200.v20250609-0437'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='0.0.0'/>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.e4.core.contexts
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.contexts.source' range='[1.13.200.v20250609-0437,1.13.200.v20250609-0437]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.core.contexts' version='1.13.200.v20250609-0437'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.core.contexts&#xA;Bundle-Version: 1.13.200.v20250609-0437
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.core.di' version='1.9.700.v20250609-0907' singleton='false' generation='2'>
      <update id='org.eclipse.e4.core.di' range='[0.0.0,1.9.700.v20250609-0907)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Dependency Injection'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.di'/>
        <property name='maven-version' value='1.9.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di' version='1.9.700.v20250609-0907'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.core.di' version='1.9.700.v20250609-0907'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.di' version='1.7.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.di.suppliers' version='1.7.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.internal.di' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.internal.di.osgi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.internal.di.shared' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.core.di' version='1.9.700.v20250609-0907'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di.annotations' range='[1.4.0,2.0.0)'/>
        <required namespace='java.package' name='jakarta.annotation' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='javax.annotation' range='[1.3.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.inject' range='[1.0.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.1,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.e4.core.di
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.source' range='[1.9.700.v20250609-0907,1.9.700.v20250609-0907]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.core.di' version='1.9.700.v20250609-0907'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.core.di&#xA;Bundle-Version: 1.9.700.v20250609-0907
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.core.di.annotations' version='1.8.400.v20240413-1529' singleton='false' generation='2'>
      <update id='org.eclipse.e4.core.di.annotations' range='[0.0.0,1.8.400.v20240413-1529)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.Bundle-Name' value='Eclipse Dependency Injection Annotations'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.di.annotations'/>
        <property name='maven-version' value='1.8.400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.annotations' version='1.8.400.v20240413-1529'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.core.di.annotations' version='1.8.400.v20240413-1529'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.di.annotations' version='1.6.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.core.di.annotations' version='1.8.400.v20240413-1529'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.e4.core.di.annotations
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.annotations.source' range='[1.8.400.v20240413-1529,1.8.400.v20240413-1529]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.core.di.annotations' version='1.8.400.v20240413-1529'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.core.di.annotations&#xA;Bundle-Version: 1.8.400.v20240413-1529
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.core.di.extensions' version='0.18.300.v20240413-1529' generation='2'>
      <update id='org.eclipse.e4.core.di.extensions' range='[0.0.0,0.18.300.v20240413-1529)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Dependency Injection Extensions'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.di.extensions'/>
        <property name='maven-version' value='0.18.300-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.extensions' version='0.18.300.v20240413-1529'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.core.di.extensions' version='0.18.300.v20240413-1529'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.di.extensions' version='0.16.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.core.di.extensions' version='0.18.300.v20240413-1529'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.0.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.e4.core.di.extensions
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.extensions.source' range='[0.18.300.v20240413-1529,0.18.300.v20240413-1529]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.core.di.extensions' version='0.18.300.v20240413-1529'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.core.di.extensions;singleton:=true&#xA;Bundle-Version: 0.18.300.v20240413-1529
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.core.di.extensions.supplier' version='0.17.1000.v20260130-1147' singleton='false' generation='2'>
      <update id='org.eclipse.e4.core.di.extensions.supplier' range='[0.0.0,0.17.1000.v20260130-1147)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.Bundle-Name' value='Eclipse Dependency Injection Extensions Supplier'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.di.extensions.supplier'/>
        <property name='maven-version' value='0.17.1000-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.extensions.supplier' version='0.17.1000.v20260130-1147'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.core.di.extensions.supplier' version='0.17.1000.v20260130-1147'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.di.internal.extensions' version='0.15.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.di.internal.extensions.util' version='0.15.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.core.di.extensions.supplier' version='0.17.1000.v20260130-1147'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='java.package' name='jakarta.annotation' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='3.3.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.contexts' range='1.6.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.di' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.di.annotations' range='1.6.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.di.extensions' range='0.15.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.di.suppliers' range='[1.7.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.4.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.3,2.0.0)'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.3)(!(version&gt;=2.0)))'>
          <description>
            org.eclipse.e4.core.di.extensions.supplier
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.e4.core.di.extensions.supplier
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.extensions.supplier.source' range='[0.17.1000.v20260130-1147,0.17.1000.v20260130-1147]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.core.di.extensions.supplier' version='0.17.1000.v20260130-1147'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.core.di.extensions.supplier&#xA;Bundle-Version: 0.17.1000.v20260130-1147
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.core.services' version='2.5.300.v20251112-1253' generation='2'>
      <update id='org.eclipse.e4.core.services' range='[0.0.0,2.5.300.v20251112-1253)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Application Services'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.services'/>
        <property name='maven-version' value='2.5.300-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.services' version='2.5.300.v20251112-1253'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.core.services' version='2.5.300.v20251112-1253'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.internal.services' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.internal.services.about' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.about' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.adapter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.contributions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.log' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.nls' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.statusreporter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.translation' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.core.services' version='2.5.300.v20251112-1253'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.4.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='3.3.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='3.5.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='0.0.0'/>
        <required namespace='java.package' name='jakarta.annotation' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.4.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.4.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'>
          <description>
            org.eclipse.e4.core.services
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.e4.core.services
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.services.source' range='[2.5.300.v20251112-1253,2.5.300.v20251112-1253]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.core.services' version='2.5.300.v20251112-1253'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.core.services;singleton:=true&#xA;Bundle-Version: 2.5.300.v20251112-1253
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.emf.xpath' version='0.6.100.v20251103-0738' singleton='false' generation='2'>
      <update id='org.eclipse.e4.emf.xpath' range='[0.0.0,0.6.100.v20251103-0738)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.Bundle-Name' value='Eclipse Model Xpath'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.emf.xpath'/>
        <property name='maven-version' value='0.6.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath' version='0.6.100.v20251103-0738'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.emf.xpath' version='0.6.100.v20251103-0738'/>
        <provided namespace='java.package' name='org.eclipse.e4.emf.xpath' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.emf.xpath' version='0.6.100.v20251103-0738'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='2.35.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.29.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' range='2.38.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.e4.emf.xpath
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath.source' range='[0.6.100.v20251103-0738,0.6.100.v20251103-0738]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.emf.xpath' version='0.6.100.v20251103-0738'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.emf.xpath;deprecated:=&quot;This bundle is deprecated since 2025-03 (removal in 2027-03 or later)&quot;&#xA;Bundle-Version: 0.6.100.v20251103-0738
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.rcp.feature.group' version='4.39.0.v20260225-1014' singleton='false'>
      <update id='org.eclipse.e4.rcp.feature.group' range='[0.0.0,4.39.0.v20260225-1014)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.rcp'/>
        <property name='maven-version' value='4.39.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2010, 2019 IBM Corporation and others.&#xA;&#xA;This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation&#xA;Lars Vogel &lt;Lars.Vogel@vogella.com&gt; - Ongoing maintenance'/>
        <property name='df_LT.featureName' value='Eclipse 4 Rich Client Platform'/>
        <property name='df_LT.description' value='The bundles typical required by Eclipse RCP applications as of version 4.0'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.rcp.feature.group' version='4.39.0.v20260225-1014'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='88'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.command' range='[1.1.2,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.runtime' range='[1.1.6,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.shell' range='[1.1.4,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.cm' range='[1.6.1,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.component' range='[1.5.1,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.device' range='[1.1.1,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.event' range='[1.4.1,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.metatype' range='[1.4.1,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.provisioning' range='[1.2.0,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.upnp' range='[1.2.1,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.useradmin' range='[1.1.1,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.wireadmin' range='[1.0.2,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.function' range='[1.2.0,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.measurement' range='[1.0.2,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.position' range='[1.0.1,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.promise' range='[1.3.0,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.xml' range='[1.0.2,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.services' range='[2.5.300.v20251112-1253,2.5.300.v20251112-1253]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt' range='[0.18.0.v20260119-0835,0.18.0.v20260119-0835]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands' range='[1.1.700.v20250916-0927,1.1.700.v20250916-0927]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings' range='[0.15.0.v20251216-1230,0.15.0.v20251216-1230]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench' range='[2.4.700.v20251029-0840,2.4.700.v20251029-0840]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.progress' range='[0.5.0.v20251217-1052,0.5.0.v20251217-1052]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services' range='[1.6.600.v20251023-1358,1.6.600.v20251023-1358]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt' range='[0.17.0.v20260131-0926,0.17.0.v20260131-0926]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench' range='[1.18.200.v20260124-1751,1.18.200.v20260124-1751]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core' range='[0.14.600.v20251112-0859,0.14.600.v20251112-0859]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt' range='[0.16.0.v20251216-1230,0.16.0.v20251216-1230]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di' range='[1.9.700.v20250609-0907,1.9.700.v20250609-0907]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.contexts' range='[1.13.200.v20250609-0437,1.13.200.v20250609-0437]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.extensions' range='[0.18.300.v20240413-1529,0.18.300.v20240413-1529]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme' range='[0.15.0.v20251216-1230,0.15.0.v20251216-1230]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di' range='[1.5.700.v20250917-0901,1.5.700.v20250917-0901]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets' range='[1.5.0.v20251217-1052,1.5.0.v20251217-1052]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa' range='[0.14.600.v20260123-2255,0.14.600.v20260123-2255]'>
          <filter>
            (&amp;(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.20.300.v20251111-0312,3.20.300.v20251111-0312]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.event' range='[1.7.300.v20250518-0609,1.7.300.v20250518-0609]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' range='[3.12.500.v20251103-0733,3.12.500.v20251103-0733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' range='[3.9.800.v20251105-1620,3.9.800.v20251105-1620]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding' range='[1.13.700.v20251023-1511,1.13.700.v20251023-1511]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.beans' range='[1.10.500.v20250916-0941,1.10.500.v20250916-0941]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable' range='[1.13.500.v20251103-0735,1.13.500.v20251103-0735]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property' range='[1.10.500.v20250916-0931,1.10.500.v20250916-0931]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' range='[3.9.500.v20250608-0434,3.9.500.v20250608-0434]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' range='[3.15.700.v20250725-1147,3.15.700.v20250725-1147]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='[3.34.200.v20251220-0953,3.34.200.v20251220-0953]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' range='[1.7.600.v20251211-1038,1.7.600.v20251211-1038]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' range='[1.7.100.v20251111-0406,1.7.100.v20251111-0406]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.12.100.v20251111-0704,3.12.100.v20251111-0704]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.12.600.v20250906-0651,3.12.600.v20250906-0651]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' range='[1.5.700.v20251111-1031,1.5.700.v20251111-1031]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' range='[3.24.100.v20251215-1416,3.24.100.v20251215-1416]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state' range='[1.3.0.v20251022-1724,1.3.0.v20251022-1724]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' range='[3.7.400.v20250516-0916,3.7.400.v20250516-0916]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64' range='[1.2.1400.v20250801-0854,1.2.1400.v20250801-0854]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.aarch64' range='[1.2.1400.v20250801-0854,1.2.1400.v20250801-0854]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.ppc64le' range='[1.2.1500.v20250801-0854,1.2.1500.v20250801-0854]'>
          <filter>
            (&amp;(osgi.arch=ppc64le)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.aarch64' range='[1.2.1500.v20250801-0854,1.2.1500.v20250801-0854]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.riscv64' range='[1.2.1500.v20250801-0854,1.2.1500.v20250801-0854]'>
          <filter>
            (&amp;(osgi.arch=riscv64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='[1.2.1500.v20250801-0854,1.2.1500.v20250801-0854]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.aarch64' range='[1.3.0.v20260203-2149,1.3.0.v20260203-2149]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86_64' range='[1.3.0.v20260203-2149,1.3.0.v20260203-2149]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.aarch64' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86_64' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.ppc64le' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=ppc64le)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.aarch64' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.riscv64' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=riscv64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.aarch64' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.svg' range='[3.132.0.v20251202-1523,3.132.0.v20251202-1523]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' range='[3.39.0.v20260122-1511,3.39.0.v20260122-1511]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding' range='[1.16.0.v20251216-1230,1.16.0.v20251216-1230]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3' range='[0.18.0.v20251216-1230,0.18.0.v20251216-1230]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.console' range='[1.4.1100.v20250722-0745,1.4.1100.v20250722-0745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt' range='[1.6.0.v20251216-1230,1.6.0.v20251216-1230]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.bidi' range='[1.5.400.v20250715-0436,1.5.400.v20250715-0436]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.dialogs' range='[1.7.0.v20251222-0947,1.7.0.v20251222-0947]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.dialogs' range='[1.7.0.v20251222-0947,1.7.0.v20251222-0947]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath' range='[0.6.100.v20251103-0738,0.6.100.v20251103-0738]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.annotations' range='[1.8.400.v20240413-1529,1.8.400.v20240413-1529]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.swt.gtk' range='[1.2.200.v20240416-0658,1.2.200.v20240416-0658]'>
          <filter>
            (osgi.ws=gtk)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.swt.win32' range='[1.2.300.v20240416-0658,1.2.300.v20240416-0658]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.extensions.supplier' range='[0.17.1000.v20260130-1147,0.17.1000.v20260130-1147]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.urischeme' range='[1.3.600.v20251023-1158,1.3.600.v20251023-1158]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.notifications' range='[0.8.0.v20251217-0909,0.8.0.v20251217-0909]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.rcp.feature.jar' range='[4.39.0.v20260225-1014,4.39.0.v20260225-1014]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.e4.rcp.feature.jar' version='4.39.0.v20260225-1014'>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2010, 2019 IBM Corporation and others.&#xA;&#xA;This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation&#xA;Lars Vogel &lt;Lars.Vogel@vogella.com&gt; - Ongoing maintenance'/>
        <property name='df_LT.featureName' value='Eclipse 4 Rich Client Platform'/>
        <property name='df_LT.description' value='The bundles typical required by Eclipse RCP applications as of version 4.0'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.rcp'/>
        <property name='maven-version' value='4.39.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.rcp.feature.jar' version='4.39.0.v20260225-1014'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.e4.rcp' version='4.39.0.v20260225-1014'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.e4.rcp' version='4.39.0.v20260225-1014'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.e4.ui.bindings' version='0.15.0.v20251216-1230' generation='2'>
      <update id='org.eclipse.e4.ui.bindings' range='[0.0.0,0.15.0.v20251216-1230)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Bindings Support'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.bindings'/>
        <property name='maven-version' value='0.15.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings' version='0.15.0.v20251216-1230'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.bindings' version='0.15.0.v20251216-1230'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.bindings' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.bindings.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.bindings.keys' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.bindings' version='0.15.0.v20251216-1230'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.133.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='1.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.services' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='2.5.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.model.workbench' range='0.0.0'/>
        <required namespace='java.package' name='jakarta.annotation' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.e4.core.commands' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.commands.internal' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.services.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.jface.bindings' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.jface.bindings.keys' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.jface.dialogs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.jface.window' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.e4.ui.bindings
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings.source' range='[0.15.0.v20251216-1230,0.15.0.v20251216-1230]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.bindings' version='0.15.0.v20251216-1230'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.bindings;singleton:=true&#xA;Bundle-Version: 0.15.0.v20251216-1230
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.css.core' version='0.14.600.v20251112-0859' generation='2'>
      <update id='org.eclipse.e4.ui.css.core' range='[0.0.0,0.14.600.v20251112-0859)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse CSS Core Support'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.css.core'/>
        <property name='maven-version' value='0.14.600-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='26'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core' version='0.14.600.v20251112-0859'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.css.core' version='0.14.600.v20251112-0859'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.css2' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.dom.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.dom.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.dom.properties.converters' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.dom.properties.css2' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.dom.properties.providers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.exceptions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.impl.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.impl.dom.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.impl.dom.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.impl.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.impl.sac' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.sac' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.serializers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.util.impl.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.util.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.utils' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.css.core' version='0.14.600.v20251112-0859'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.apache.batik.css' range='[1.9.1,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='java.package' name='org.w3c.css.sac' range='1.3.0'/>
        <required namespace='java.package' name='org.w3c.css.sac.helpers' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.e4.ui.css.core
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core.source' range='[0.14.600.v20251112-0859,0.14.600.v20251112-0859]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.css.core' version='0.14.600.v20251112-0859'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.css.core;singleton:=true&#xA;Bundle-Version: 0.14.600.v20251112-0859
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.css.swt' version='0.16.0.v20251216-1230' generation='2'>
      <update id='org.eclipse.e4.ui.css.swt' range='[0.0.0,0.16.0.v20251216-1230)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse CSS SWT Support'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.css.swt'/>
        <property name='maven-version' value='0.16.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='22'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt' version='0.16.0.v20251216-1230'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt' version='0.16.0.v20251216-1230'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.dom.definition' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.dom.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.dom.preference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.properties.converters' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.properties.css2' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.properties.custom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.properties.definition' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.properties.preference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.serializers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.css.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.css.swt.definition' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.css.swt' version='0.16.0.v20251216-1230'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.core' range='0.12.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.133.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.jface.resource' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.css.sac' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.e4.ui.css.swt
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.source' range='[0.16.0.v20251216-1230,0.16.0.v20251216-1230]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.css.swt' version='0.16.0.v20251216-1230'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.css.swt;singleton:=true&#xA;Bundle-Version: 0.16.0.v20251216-1230
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.css.swt.theme' version='0.15.0.v20251216-1230' generation='2'>
      <update id='org.eclipse.e4.ui.css.swt.theme' range='[0.0.0,0.15.0.v20251216-1230)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse CSS SWT Theme Support'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.css.swt.theme'/>
        <property name='maven-version' value='0.15.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme' version='0.15.0.v20251216-1230'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt.theme' version='0.15.0.v20251216-1230'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.internal.theme' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.theme' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.css.swt.theme' version='0.15.0.v20251216-1230'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.133.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt' range='0.13.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.core' range='0.12.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.w3c.css.sac' range='1.3.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'>
          <description>
            org.eclipse.e4.ui.css.swt.theme
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.e4.ui.css.swt.theme
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme.source' range='[0.15.0.v20251216-1230,0.15.0.v20251216-1230]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.css.swt.theme' version='0.15.0.v20251216-1230'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.css.swt.theme;singleton:=true&#xA;Bundle-Version: 0.15.0.v20251216-1230
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.di' version='1.5.700.v20250917-0901' singleton='false' generation='2'>
      <update id='org.eclipse.e4.ui.di' range='[0.0.0,1.5.700.v20250917-0901)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse UI Dependency Injection'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.di'/>
        <property name='maven-version' value='1.5.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di' version='1.5.700.v20250917-0901'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.di' version='1.5.700.v20250917-0901'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.di' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.di' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.di' version='1.5.700.v20250917-0901'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.e4.core.contexts' range='1.6.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.di.annotations' range='0.15.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.di.internal.extensions' range='0.15.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.di.suppliers' range='[1.7.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,2.0.0)'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'>
          <description>
            org.eclipse.e4.ui.di
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.e4.ui.di
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di.source' range='[1.5.700.v20250917-0901,1.5.700.v20250917-0901]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.di' version='1.5.700.v20250917-0901'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.di&#xA;Bundle-Version: 1.5.700.v20250917-0901
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.dialogs' version='1.7.0.v20251222-0947' singleton='false' generation='2'>
      <update id='org.eclipse.e4.ui.dialogs' range='[0.0.0,1.7.0.v20251222-0947)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse e4 dialogs'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.dialogs'/>
        <property name='maven-version' value='1.7.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.dialogs' version='1.7.0.v20251222-0947'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.dialogs' version='1.7.0.v20251222-0947'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.dialogs.filteredtree' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.dialogs.textbundles' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.dialogs.about' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.dialogs' version='1.7.0.v20251222-0947'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='3.39.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.29.0'/>
        <requiredProperties namespace='eclipse.swt' match='(image.format=svg)'>
          <description>
            org.eclipse.e4.ui.dialogs
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.e4.ui.dialogs
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.dialogs.source' range='[1.7.0.v20251222-0947,1.7.0.v20251222-0947]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.dialogs' version='1.7.0.v20251222-0947'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.dialogs&#xA;Bundle-Version: 1.7.0.v20251222-0947
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.model.workbench' version='2.4.700.v20251029-0840' generation='2'>
      <update id='org.eclipse.e4.ui.model.workbench' range='[0.0.0,2.4.700.v20251029-0840)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Workbench Model'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.model.workbench'/>
        <property name='maven-version' value='2.4.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='31'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench' version='2.4.700.v20251029-0840'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.model.workbench' version='2.4.700.v20251029-0840'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.commands.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.commands.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.descriptor.basic' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.descriptor.basic.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.descriptor.basic.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.advanced' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.advanced.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.advanced.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.basic' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.basic.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.basic.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.menu' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.menu.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.menu.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.fragment' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.fragment.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.fragment.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.internal' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.model.workbench' version='2.4.700.v20251029-0840'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='2.35.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.emf.xpath' range='0.1.100'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.e4.ui.model.workbench
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench.source' range='[2.4.700.v20251029-0840,2.4.700.v20251029-0840]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.model.workbench' version='2.4.700.v20251029-0840'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.model.workbench;singleton:=true&#xA;Bundle-Version: 2.4.700.v20251029-0840
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.progress' version='0.5.0.v20251217-1052' generation='2'>
      <update id='org.eclipse.e4.ui.progress' range='[0.0.0,0.5.0.v20251217-1052)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse e4 Progress View'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.progress'/>
        <property name='maven-version' value='0.5.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.progress' version='0.5.0.v20251217-1052'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.progress' version='0.5.0.v20251217-1052'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.progress' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.progress' version='0.5.0.v20251217-1052'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='1.3.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.di' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='3.39.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.commands' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.model.workbench' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench.swt' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.services' range='0.0.0'/>
        <required namespace='java.package' name='jakarta.annotation' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <requiredProperties namespace='eclipse.swt' match='(image.format=svg)'>
          <description>
            org.eclipse.e4.ui.progress
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.e4.ui.progress
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.progress.source' range='[0.5.0.v20251217-1052,0.5.0.v20251217-1052]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.progress' version='0.5.0.v20251217-1052'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.progress;singleton:=true&#xA;Bundle-Version: 0.5.0.v20251217-1052
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.services' version='1.6.600.v20251023-1358' generation='2'>
      <update id='org.eclipse.e4.ui.services' range='[0.0.0,1.6.600.v20251023-1358)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse UI Application Services'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.services'/>
        <property name='maven-version' value='1.6.600-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services' version='1.6.600.v20251023-1358'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.services' version='1.6.600.v20251023-1358'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.services' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.services' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.services.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.services.help' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.services.internal.events' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.services' version='1.6.600.v20251023-1358'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.di' range='0.9.0'/>
        <required namespace='java.package' name='jakarta.annotation' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.4.0,2.0.0)'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'>
          <description>
            org.eclipse.e4.ui.services
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.service' match='(objectClass=org.osgi.service.event.EventAdmin)'>
          <description>
            org.eclipse.e4.ui.services
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.e4.ui.services
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services.source' range='[1.6.600.v20251023-1358,1.6.600.v20251023-1358]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.services' version='1.6.600.v20251023-1358'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.services;singleton:=true&#xA;Bundle-Version: 1.6.600.v20251023-1358
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.swt.gtk' version='1.2.200.v20240416-0658' generation='2'>
      <update id='org.eclipse.e4.ui.swt.gtk' range='[0.0.0,1.2.200.v20240416-0658)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.fragmentName' value='Eclipse UI GTK Enhancements'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment-gtk'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.swt.gtk'/>
        <property name='maven-version' value='1.2.200-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.swt.gtk' version='1.2.200.v20240416-0658'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.swt.gtk' version='1.2.200.v20240416-0658'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.swt.gtk' version='1.2.200.v20240416-0658'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.e4.ui.css.swt.theme' version='1.2.200.v20240416-0658'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt.theme' range='0.10.0'/>
        <required namespace='java.package' name='jakarta.annotation' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.e4.core.services.events' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.3.1'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.e4.ui.swt.gtk
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.swt.gtk.source' range='[1.2.200.v20240416-0658,1.2.200.v20240416-0658]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <filter>
        (osgi.ws=gtk)
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.swt.gtk' version='1.2.200.v20240416-0658'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.swt.gtk;singleton:=true&#xA;Bundle-Version: 1.2.200.v20240416-0658&#xA;Fragment-Host: org.eclipse.e4.ui.css.swt.theme;bundle-version=&quot;0.10.0&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.widgets' version='1.5.0.v20251217-1052' singleton='false' generation='2'>
      <update id='org.eclipse.e4.ui.widgets' range='[0.0.0,1.5.0.v20251217-1052)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse UI Custom widgets'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.widgets'/>
        <property name='maven-version' value='1.5.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets' version='1.5.0.v20251217-1052'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.widgets' version='1.5.0.v20251217-1052'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.widgets' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.widgets' version='1.5.0.v20251217-1052'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.133.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.e4.ui.widgets
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets.source' range='[1.5.0.v20251217-1052,1.5.0.v20251217-1052]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.widgets' version='1.5.0.v20251217-1052'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.widgets&#xA;Bundle-Version: 1.5.0.v20251217-1052
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.workbench' version='1.18.200.v20260124-1751' generation='2'>
      <update id='org.eclipse.e4.ui.workbench' range='[0.0.0,1.18.200.v20260124-1751)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse e4 Workbench'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.workbench'/>
        <property name='maven-version' value='1.18.200-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench' version='1.18.200.v20260124-1751'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench' version='1.18.200.v20260124-1751'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.workbench' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.addons' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.lifecycle' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.modeling' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.workbench' version='1.18.200.v20260124-1751'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.model.workbench' range='1.2.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.services' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='1.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.commands' range='0.11.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.change' range='2.5.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.di' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' range='2.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di.extensions' range='0.18.300'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='java.package' name='jakarta.annotation' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.event.propertytypes' range='[1.4.0,2.0.0)'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'>
          <description>
            org.eclipse.e4.ui.workbench
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.service' match='(objectClass=org.osgi.service.event.EventAdmin)'>
          <description>
            org.eclipse.e4.ui.workbench
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.e4.ui.workbench
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.source' range='[1.18.200.v20260124-1751,1.18.200.v20260124-1751]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.workbench' version='1.18.200.v20260124-1751'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.workbench;singleton:=true&#xA;Bundle-Version: 1.18.200.v20260124-1751
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.workbench.addons.swt' version='1.6.0.v20251216-1230' generation='2'>
      <update id='org.eclipse.e4.ui.workbench.addons.swt' range='[0.0.0,1.6.0.v20251216-1230)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse e4 Workbench Add-ons'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.workbench.addons.swt'/>
        <property name='maven-version' value='1.6.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt' version='1.6.0.v20251216-1230'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench.addons.swt' version='1.6.0.v20251216-1230'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.addons.cleanupaddon' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.addons.dndaddon' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.addons.minmax' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.addons.splitteraddon' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.addons.swt' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.workbench.addons.swt' version='1.6.0.v20251216-1230'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.model.workbench' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench' range='1.5.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='0.9.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench.renderers.swt' range='0.9.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.widgets' range='0.11.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.133.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.di' range='0.10.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.services' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' range='2.7.0'/>
        <required namespace='java.package' name='jakarta.annotation' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.swt' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,2.0.0)'/>
        <requiredProperties namespace='eclipse.swt' match='(image.format=svg)'>
          <description>
            org.eclipse.e4.ui.workbench.addons.swt
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.e4.ui.workbench.addons.swt
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt.source' range='[1.6.0.v20251216-1230,1.6.0.v20251216-1230]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.workbench.addons.swt' version='1.6.0.v20251216-1230'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.workbench.addons.swt;singleton:=true&#xA;Bundle-Version: 1.6.0.v20251216-1230
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.workbench.renderers.swt' version='0.17.0.v20260131-0926' generation='2'>
      <update id='org.eclipse.e4.ui.workbench.renderers.swt' range='[0.0.0,0.17.0.v20260131-0926)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse e4 Workbench SWT Renderer'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.workbench.renderers.swt'/>
        <property name='maven-version' value='0.17.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt' version='0.17.0.v20260131-0926'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench.renderers.swt' version='0.17.0.v20260131-0926'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.renderers.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.renderers.swt' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.workbench.renderers.swt' version='0.17.0.v20260131-0926'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='24'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='2.5.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='1.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.services' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.133.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.15.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench.swt' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.model.workbench' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.commands' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.bindings' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.core' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.di' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='2.35.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt' range='0.11.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di.extensions' range='0.12.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.29.0'/>
        <required namespace='java.package' name='jakarta.annotation' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,2.0.0)'/>
        <requiredProperties namespace='eclipse.swt' match='(image.format=svg)'>
          <description>
            org.eclipse.e4.ui.workbench.renderers.swt
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.e4.ui.workbench.renderers.swt
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.source' range='[0.17.0.v20260131-0926,0.17.0.v20260131-0926]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.workbench.renderers.swt' version='0.17.0.v20260131-0926'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.workbench.renderers.swt;singleton:=true&#xA;Bundle-Version: 0.17.0.v20260131-0926
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.workbench.swt' version='0.18.0.v20260119-0835' generation='2'>
      <update id='org.eclipse.e4.ui.workbench.swt' range='[0.0.0,0.18.0.v20260119-0835)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse e4 Workbench SWT'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.workbench.swt'/>
        <property name='maven-version' value='0.18.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt' version='0.18.0.v20260119-0835'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench.swt' version='0.18.0.v20260119-0835'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.swt.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.swt.factories' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.swt.internal.copy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.swt.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.workbench.swt' version='0.18.0.v20260119-0835'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='34'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench' range='0.10.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.services' range='0.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.39.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.dialogs' range='1.1.600'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.databinding' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.core' range='0.12.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt' range='0.13.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.bindings' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench3' range='0.11.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='1.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt.theme' range='0.12.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.200,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.commands' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.widgets' range='0.11.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.di' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' range='2.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.model.workbench' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di.extensions' range='0.18.300'/>
        <required namespace='osgi.bundle' name='org.eclipse.urischeme' range='1.1.0'/>
        <required namespace='java.package' name='jakarta.annotation' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='jakarta.inject' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.4.0,2.0.0)'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'>
          <description>
            org.eclipse.e4.ui.workbench.swt
          </description>
        </requiredProperties>
        <requiredProperties namespace='eclipse.swt' match='(image.format=svg)'>
          <description>
            org.eclipse.e4.ui.workbench.swt
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.e4.ui.workbench.swt
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt.source' range='[0.18.0.v20260119-0835,0.18.0.v20260119-0835]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.workbench.swt' version='0.18.0.v20260119-0835'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.workbench.swt;singleton:=true&#xA;Bundle-Version: 0.18.0.v20260119-0835
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.workbench3' version='0.18.0.v20251216-1230' generation='2'>
      <update id='org.eclipse.e4.ui.workbench3' range='[0.0.0,0.18.0.v20251216-1230)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Bundle for Workbench APIs available in e4'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.workbench3'/>
        <property name='maven-version' value='0.18.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3' version='0.18.0.v20251216-1230'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench3' version='0.18.0.v20251216-1230'/>
        <provided namespace='java.package' name='org.eclipse.ui.testing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.testing.dumps' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.workbench3' version='0.18.0.v20251216-1230'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.133.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.e4.ui.workbench3
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3.source' range='[0.18.0.v20251216-1230,0.18.0.v20251216-1230]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.workbench3' version='0.18.0.v20251216-1230'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.workbench3;singleton:=true&#xA;Bundle-Version: 0.18.0.v20251216-1230
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.common' version='2.45.0.v20251210-1145' generation='2'>
      <update id='org.eclipse.emf.common' range='[0.0.0,2.45.0.v20251210-1145)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='EMF Common'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.common'/>
        <property name='maven-version' value='2.45.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common' version='2.45.0.v20251210-1145'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.common' version='2.45.0.v20251210-1145'/>
        <provided namespace='java.package' name='org.eclipse.emf.common' version='2.45.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.archive' version='2.45.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.command' version='2.45.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.notify' version='2.45.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.notify.impl' version='2.45.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.util' version='2.45.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.common' version='2.45.0.v20251210-1145'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.9.0,4.0.0)' optional='true'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.emf.common
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.source' range='[2.45.0.v20251210-1145,2.45.0.v20251210-1145]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.common' version='2.45.0.v20251210-1145'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.common;singleton:=true&#xA;Bundle-Version: 2.45.0.v20251210-1145
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.ecore' version='2.42.0.v20251210-1145' generation='2'>
      <update id='org.eclipse.emf.ecore' range='[0.0.0,2.42.0.v20251210-1145)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='EMF Ecore'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.ecore'/>
        <property name='maven-version' value='2.42.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='24'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore' version='2.42.0.v20251210-1145'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.ecore' version='2.42.0.v20251210-1145'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.impl' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.plugin' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.resource' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.resource.impl' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.util' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.namespace' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.namespace.impl' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.namespace.util' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type.impl' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type.internal' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type.util' version='2.42.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.ecore' version='2.42.0.v20251210-1145'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.generated_package' name='org.eclipse.emf.ecore_2.42.0.v20251210-1145-1' version='0.0.0'>
          <properties size='3'>
            <property name='uri' value='http://www.eclipse.org/emf/2002/Ecore'/>
            <property name='genModel' value='model/Ecore.genmodel'/>
            <property name='class' value='org.eclipse.emf.ecore.EcorePackage'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.generated_package' name='org.eclipse.emf.ecore_2.42.0.v20251210-1145-2' version='0.0.0'>
          <properties size='3'>
            <property name='uri' value='http://www.w3.org/XML/1998/namespace'/>
            <property name='genModel' value='model/XMLNamespace.genmodel'/>
            <property name='class' value='org.eclipse.emf.ecore.xml.namespace.XMLNamespacePackage'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.generated_package' name='org.eclipse.emf.ecore_2.42.0.v20251210-1145-3' version='0.0.0'>
          <properties size='3'>
            <property name='uri' value='http://www.eclipse.org/emf/2003/XMLType'/>
            <property name='genModel' value='model/XMLType.genmodel'/>
            <property name='class' value='org.eclipse.emf.ecore.xml.type.XMLTypePackage'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.dynamic_package' name='org.eclipse.emf.ecore_2.42.0.v20251210-1145-4' version='0.0.0'>
          <properties size='2'>
            <property name='location' value='model/ExtendedMetaData.ecore'/>
            <property name='uri' value='http:///org/eclipse/emf/ecore/util/ExtendedMetaData'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.dynamic_package' name='org.eclipse.emf.ecore_2.42.0.v20251210-1145-5' version='0.0.0'>
          <properties size='2'>
            <property name='location' value='model/EcoreAnnotation.ecore'/>
            <property name='uri' value='http:///org/eclipse/emf/ecore/util/EcoreAnnotation'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.dynamic_package' name='org.eclipse.emf.ecore_2.42.0.v20251210-1145-6' version='0.0.0'>
          <properties size='2'>
            <property name='location' value='model/DateConversionDelegateAnnotation.ecore'/>
            <property name='uri' value='http:///org/eclipse/emf/ecore/util/DateConversionDelegateAnnotation'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.9.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.common' range='[2.45.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.8.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.datatype' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.namespace' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.emf.ecore
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.source' range='[2.42.0.v20251210-1145,2.42.0.v20251210-1145]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.ecore' version='2.42.0.v20251210-1145'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.ecore;singleton:=true&#xA;Bundle-Version: 2.42.0.v20251210-1145
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.ecore.change' version='2.17.0.v20250910-1205' generation='2'>
      <update id='org.eclipse.emf.ecore.change' range='[0.0.0,2.17.0.v20250910-1205)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='EMF Change Model'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.ecore.change'/>
        <property name='maven-version' value='2.17.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change' version='2.17.0.v20250910-1205'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.ecore.change' version='2.17.0.v20250910-1205'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.change' version='2.17.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.change.impl' version='2.17.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.change.util' version='2.17.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.ecore.change' version='2.17.0.v20250910-1205'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.generated_package' name='org.eclipse.emf.ecore.change_2.17.0.v20250910-1205-1' version='0.0.0'>
          <properties size='3'>
            <property name='uri' value='http://www.eclipse.org/emf/2003/Change'/>
            <property name='genModel' value='model/Change.genmodel'/>
            <property name='class' value='org.eclipse.emf.ecore.change.ChangePackage'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.9.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='[2.37.0,3.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.emf.ecore.change
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change.source' range='[2.17.0.v20250910-1205,2.17.0.v20250910-1205]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.ecore.change' version='2.17.0.v20250910-1205'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.ecore.change;singleton:=true&#xA;Bundle-Version: 2.17.0.v20250910-1205
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.ecore.xmi' version='2.40.0.v20251210-1145' generation='2'>
      <update id='org.eclipse.emf.ecore.xmi' range='[0.0.0,2.40.0.v20251210-1145)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='EMF XML/XMI Persistence'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.ecore.xmi'/>
        <property name='maven-version' value='2.40.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi' version='2.40.0.v20251210-1145'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' version='2.40.0.v20251210-1145'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xmi' version='2.40.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xmi.impl' version='2.40.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xmi.util' version='2.40.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.ecore.xmi' version='2.40.0.v20251210-1145'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.9.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='[2.42.0,3.0.0)'/>
        <required namespace='java.package' name='javax.xml.namespace' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.emf.ecore.xmi
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi.source' range='[2.40.0.v20251210-1145,2.40.0.v20251210-1145]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.ecore.xmi' version='2.40.0.v20251210-1145'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.ecore.xmi; singleton:=true&#xA;Bundle-Version: 2.40.0.v20251210-1145
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.app' version='1.7.600.v20251211-1038' generation='2'>
      <update id='org.eclipse.equinox.app' range='[0.0.0,1.7.600.v20251211-1038)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Application Container'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.app'/>
        <property name='maven-version' value='1.7.600-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' version='1.7.600.v20251211-1038'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.app' version='1.7.600.v20251211-1038'/>
        <provided namespace='java.package' name='org.eclipse.equinox.app' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.app' version='0.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.application' version='1.1.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.app' version='1.7.600.v20251211-1038'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.runnable' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.condpermadmin' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.app
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app.source' range='[1.7.600.v20251211-1038,1.7.600.v20251211-1038]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.app' version='1.7.600.v20251211-1038'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.app; singleton:=true&#xA;Bundle-Version: 1.7.600.v20251211-1038
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.bidi' version='1.5.400.v20250715-0436' generation='2'>
      <update id='org.eclipse.equinox.bidi' range='[0.0.0,1.5.400.v20250715-0436)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Bidirectional Text Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.bidi'/>
        <property name='maven-version' value='1.5.400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.bidi' version='1.5.400.v20250715-0436'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.bidi' version='1.5.400.v20250715-0436'/>
        <provided namespace='java.package' name='org.eclipse.equinox.bidi' version='0.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.equinox.bidi.custom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.bidi.advanced' version='0.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.equinox.bidi.custom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.bidi.custom' version='0.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.equinox.bidi.advanced' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.bidi.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.bidi.internal.consumable' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.bidi' version='1.5.400.v20250715-0436'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.6.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='3.5.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.5.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.bidi
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.bidi.source' range='[1.5.400.v20250715-0436,1.5.400.v20250715-0436]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.bidi' version='1.5.400.v20250715-0436'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.bidi;singleton:=true&#xA;Bundle-Version: 1.5.400.v20250715-0436
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.common' version='3.20.300.v20251111-0312' generation='2'>
      <update id='org.eclipse.equinox.common' range='[0.0.0,3.20.300.v20251111-0312)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Common Eclipse Runtime'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.common'/>
        <property name='maven-version' value='3.20.300-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' version='3.20.300.v20251111-0312'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.common' version='3.20.300.v20251111-0312'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'>
          <properties size='2'>
            <property name='java.package.attribute.common' value='split'/>
            <property name='java.package.directive.mandatory' value='common' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.7.0'>
          <properties size='3'>
            <property name='java.package.attribute.common' value='split'/>
            <property name='java.package.directive.mandatory' value='common' type='List'/>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.core.text' version='3.14.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.events' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.common' version='3.20.300.v20251111-0312'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.17.200,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.common
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common.source' range='[3.20.300.v20251111-0312,3.20.300.v20251111-0312]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.common' version='3.20.300.v20251111-0312'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.common; singleton:=true&#xA;Bundle-Version: 3.20.300.v20251111-0312
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.console' version='1.4.1100.v20250722-0745' singleton='false' generation='2'>
      <update id='org.eclipse.equinox.console' range='[0.0.0,1.4.1100.v20250722-0745)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleVendor' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Console plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.console'/>
        <property name='maven-version' value='1.4.1100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.console' version='1.4.1100.v20250722-0745'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.console' version='1.4.1100.v20250722-0745'/>
        <provided namespace='java.package' name='org.eclipse.equinox.console.common' version='0.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.felix.service.command,org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.console.common.terminal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.console.completion.common' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.console' version='1.4.1100.v20250722-0745'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='java.package' name='org.apache.felix.service.command' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.container' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.report.resolution' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.hooks.resolver' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.namespace' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.resource' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.4.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.condpermadmin' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.permissionadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='org.apache.felix.gogo' match='(org.apache.felix.gogo=runtime.implementation)'>
          <description>
            org.eclipse.equinox.console
          </description>
        </requiredProperties>
        <requiredProperties namespace='org.apache.felix.gogo' match='(org.apache.felix.gogo=shell.implementation)'>
          <description>
            org.eclipse.equinox.console
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.console
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.console.source' range='[1.4.1100.v20250722-0745,1.4.1100.v20250722-0745]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.console' version='1.4.1100.v20250722-0745'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.console&#xA;Bundle-Version: 1.4.1100.v20250722-0745
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.event' version='1.7.300.v20250518-0609' singleton='false' generation='2'>
      <update id='org.eclipse.equinox.event' range='[0.0.0,1.7.300.v20250518-0609)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleVendor' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Event Admin'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.event'/>
        <property name='maven-version' value='1.7.300-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.event' version='1.7.300.v20250518-0609'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.event' version='1.7.300.v20250518-0609'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.event' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.event.mapper' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.event' version='1.7.300.v20250518-0609'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.equinox.event_1.7.300.v20250518-0609-1' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.event.EventAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.implementation' name='osgi.event' version='1.4.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.0)(!(version&gt;=2.0)))'>
          <description>
            org.eclipse.equinox.event
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.event
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.event.source' range='[1.7.300.v20250518-0609,1.7.300.v20250518-0609]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.event' version='1.7.300.v20250518-0609'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.event&#xA;Bundle-Version: 1.7.300.v20250518-0609
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher' version='1.7.100.v20251111-0406' generation='2'>
      <update id='org.eclipse.equinox.launcher' range='[0.0.0,1.7.100.v20251111-0406)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Launcher'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.launcher'/>
        <property name='maven-version' value='1.7.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' version='1.7.100.v20251111-0406'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher' version='1.7.100.v20251111-0406'/>
        <provided namespace='java.package' name='org.eclipse.equinox.launcher' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.launcher' version='1.7.100.v20251111-0406'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.launcher
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.source' range='[1.7.100.v20251111-0406,1.7.100.v20251111-0406]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher' version='1.7.100.v20251111-0406'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher;singleton:=true&#xA;Bundle-Version: 1.7.100.v20251111-0406
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.1500.v20250801-0854'>
      <update id='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='[0.0.0,1.2.1500.v20250801-0854)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Launcher Linux X86_64 Fragment'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher.gtk.linux.x86_64'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.launcher.gtk.linux.x86_64'/>
        <property name='maven-version' value='1.2.1500-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.1500.v20250801-0854'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.1500.v20250801-0854'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.1500.v20250801-0854'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.equinox.launcher' version='1.2.1500.v20250801-0854'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.7.0,1.8.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64.source' range='[1.2.1500.v20250801-0854,1.2.1500.v20250801-0854]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.1500.v20250801-0854'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher.gtk.linux.x86_64;singleton:=true&#xA;Bundle-Version: 1.2.1500.v20250801-0854&#xA;Fragment-Host: org.eclipse.equinox.launcher;bundle-version=&quot;[1.7.0,1.8.0)&quot;
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.preferences' version='3.12.100.v20251111-0704' generation='2'>
      <update id='org.eclipse.equinox.preferences' range='[0.0.0,3.12.100.v20251111-0704)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Preferences Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.preferences'/>
        <property name='maven-version' value='3.12.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' version='3.12.100.v20251111-0704'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.preferences' version='3.12.100.v20251111-0704'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.exchange' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.preferences' version='3.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime,org.osgi.service.prefs' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.preferences' version='3.12.100.v20251111-0704'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.osgi.service.prefs' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.10.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.preferences
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences.source' range='[3.12.100.v20251111-0704,3.12.100.v20251111-0704]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.preferences' version='3.12.100.v20251111-0704'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.preferences; singleton:=true&#xA;Bundle-Version: 3.12.100.v20251111-0704
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.registry' version='3.12.600.v20250906-0651' generation='2'>
      <update id='org.eclipse.equinox.registry' range='[0.0.0,3.12.600.v20250906-0651)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Extension Registry Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.registry'/>
        <property name='maven-version' value='3.12.600-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' version='3.12.600.v20250906-0651'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.registry' version='3.12.600.v20250906-0651'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.adapter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.osgi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.7.0'>
          <properties size='3'>
            <property name='java.package.directive.mandatory' value='registry' type='List'/>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime.spi,org.osgi.framework' type='List'/>
            <property name='java.package.attribute.registry' value='split'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.core.runtime.dynamichelpers' version='3.4.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.core.runtime.spi' version='3.4.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.parsers,org.eclipse.core.runtime' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.registry' version='3.12.600.v20250906-0651'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.15.100,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.container' range='[1.9.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.registry
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry.source' range='[3.12.600.v20250906-0651,3.12.600.v20250906-0651]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.registry' version='3.12.600.v20250906-0651'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.registry;singleton:=true&#xA;Bundle-Version: 3.12.600.v20250906-0651
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.simpleconfigurator' version='1.5.700.v20251111-1031' generation='2'>
      <update id='org.eclipse.equinox.simpleconfigurator' range='[0.0.0,1.5.700.v20251111-1031)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleName' value='Simple Configurator'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.simpleconfigurator'/>
        <property name='maven-version' value='1.5.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' version='1.5.700.v20251111-1031'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' version='1.5.700.v20251111-1031'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.utils' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.simpleconfigurator' version='1.5.700.v20251111-1031'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='java.package' name='org.eclipse.osgi.container' range='[1.9.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.report.resolution' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.7.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.hooks.resolver' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.namespace' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.resource' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.resolver' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.simpleconfigurator
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.source' range='[1.5.700.v20251111-1031,1.5.700.v20251111-1031]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.simpleconfigurator' version='1.5.700.v20251111-1031'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.simpleconfigurator;singleton:=true&#xA;Bundle-Version: 1.5.700.v20251111-1031
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jface' version='3.39.0.v20260122-1511' generation='2'>
      <update id='org.eclipse.jface' range='[0.0.0,3.39.0.v20260122-1511)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='JFace'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.jface'/>
        <property name='maven-version' value='3.39.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='34'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' version='3.39.0.v20260122-1511'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jface' version='3.39.0.v20260122-1511'/>
        <provided namespace='java.package' name='org.eclipse.jface' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.action' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.action.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings.keys' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings.keys.formatting' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.dialogs.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.fieldassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.fieldassist.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.provisional.action' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.menus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.operation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.preference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.preference.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.resource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.viewers.deferred' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.viewers.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.widgets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.window' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.wizard' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.wizard.images' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.jface' version='3.39.0.v20260122-1511'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <requiredProperties namespace='eclipse.swt' match='(image.format=svg)'>
          <description>
            org.eclipse.jface
          </description>
        </requiredProperties>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.bidi' range='[0.10.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.source' range='[3.39.0.v20260122-1511,3.39.0.v20260122-1511]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.126.0,4.0.0)'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.jface
          </description>
        </requiredProperties>
        <required match='providedCapabilities.exists(x | x.name == $0 &amp;&amp; x.namespace == $1 &amp;&amp; x.version &gt;= $2 &amp;&amp; x.version &lt;= $3)' matchParameters='[&apos;com.genuitec.eclipse.theming.core.feature.feature.group&apos;, &apos;org.eclipse.equinox.p2.iu&apos;, version(&apos;0.0.1&apos;), version(&apos;2024.4.0.202412101111&apos;)]' min='0' max='0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jface' version='3.39.0.v20260122-1511'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jface;singleton:=true&#xA;Bundle-Version: 3.39.0.v20260122-1511
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jface.databinding' version='1.16.0.v20251216-1230' singleton='false' generation='2'>
      <update id='org.eclipse.jface.databinding' range='[0.0.0,1.16.0.v20251216-1230)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='JFace Data Binding for SWT and JFace'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.jface.databinding'/>
        <property name='maven-version' value='1.16.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='19'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding' version='1.16.0.v20251216-1230'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jface.databinding' version='1.16.0.v20251216-1230'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.dialog' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.fieldassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.preference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.swt.typed' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.viewers.typed' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.wizard' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.provisional.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.provisional.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.viewers' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.jface.databinding' version='1.16.0.v20251216-1230'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.133.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.property' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding' range='[1.2.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.jface.databinding
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding.source' range='[1.16.0.v20251216-1230,1.16.0.v20251216-1230]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jface.databinding' version='1.16.0.v20251216-1230'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jface.databinding&#xA;Bundle-Version: 1.16.0.v20251216-1230
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jface.notifications' version='0.8.0.v20251217-0909' singleton='false' generation='2'>
      <update id='org.eclipse.jface.notifications' range='[0.0.0,0.8.0.v20251217-0909)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Notification API'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.jface.notifications'/>
        <property name='maven-version' value='0.8.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.notifications' version='0.8.0.v20251217-0909'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jface.notifications' version='0.8.0.v20251217-0909'/>
        <provided namespace='java.package' name='org.eclipse.jface.notifications' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.notifications.internal' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.jface.notifications' version='0.8.0.v20251217-0909'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.29.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='3.39.0'/>
        <requiredProperties namespace='eclipse.swt' match='(image.format=svg)'>
          <description>
            org.eclipse.jface.notifications
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.jface.notifications
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.notifications.source' range='[0.8.0.v20251217-0909,0.8.0.v20251217-0909]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jface.notifications' version='0.8.0.v20251217-0909'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jface.notifications&#xA;Bundle-Version: 0.8.0.v20251217-0909
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.orbit.xml-apis-ext' version='1.0.0.v20240917-0534' singleton='false' generation='2'>
      <update id='org.eclipse.orbit.xml-apis-ext' range='[0.0.0,1.0.0.v20240917-0534)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='Extended XML APIs'/>
        <property name='org.eclipse.equinox.p2.provider' value='Orbit Project'/>
        <property name='maven-groupId' value='org.eclipse.orbit.legacy'/>
        <property name='maven-artifactId' value='org.eclipse.orbit.xml-apis-ext'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.orbit.xml-apis-ext' version='1.0.0.v20240917-0534'/>
        <provided namespace='osgi.bundle' name='org.eclipse.orbit.xml-apis-ext' version='1.0.0.v20240917-0534'/>
        <provided namespace='java.package' name='org.w3c.css.sac' version='1.3.0'/>
        <provided namespace='java.package' name='org.w3c.css.sac.helpers' version='1.3.0'/>
        <provided namespace='java.package' name='org.w3c.dom.smil' version='1.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.svg' version='1.1.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.orbit.xml-apis-ext' version='1.0.0.v20240917-0534'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom.events' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom.css' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom.views' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.orbit.xml-apis-ext
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.orbit.xml-apis-ext.source' range='[1.0.0.v20240917-0534,1.0.0.v20240917-0534]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.orbit.xml-apis-ext' version='1.0.0.v20240917-0534'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.orbit.xml-apis-ext&#xA;Bundle-Version: 1.0.0.v20240917-0534
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi' version='3.24.100.v20251215-1416' generation='2'>
      <update id='org.eclipse.osgi' range='[0.0.0,3.24.100.v20251215-1416)' severity='0'/>
      <properties size='11'>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.systemBundle' value='OSGi System Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.description' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='systembundle'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.osgi'/>
        <property name='maven-version' value='3.24.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='97'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' version='3.24.100.v20251215-1416'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi' version='3.24.100.v20251215-1416'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.internal.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.log' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework,org.osgi.service.log' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.container' version='1.9.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.osgi.report.resolution,org.osgi.framework.wiring,org.eclipse.osgi.framework.eventmgr,org.osgi.framework.startlevel,org.osgi.framework,org.osgi.framework.hooks.resolver,org.osgi.service.resolver,org.osgi.resource,org.eclipse.osgi.service.debug' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.container.builders' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.osgi.util,org.eclipse.osgi.container' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.container.namespaces' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.resource' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.console' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.reliablefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.log' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.framework' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.hookregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.buddy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.classpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.sources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.location' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.messages' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.service.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.serviceregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.signedcontent' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.url' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.launch' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework,org.osgi.framework.launch,org.osgi.framework.connect' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.report.resolution' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.service.resolver,org.osgi.resource' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.service.datalocation' version='1.4.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.debug' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.environment' version='1.4.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.localization' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.resolver' version='1.7.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework,org.osgi.framework.hooks.resolver,org.osgi.framework.wiring' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.service.runnable' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.urlconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.signedcontent' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.bundlefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.url.reference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storagemanager' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.util' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.dto' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.framework' version='1.10.0'/>
        <provided namespace='java.package' name='org.osgi.framework.connect' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework.launch' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.dto' version='1.8.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.dto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.hooks.bundle' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.hooks.resolver' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework.wiring' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.hooks.service' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.hooks.weaving' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework.wiring' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.launch' version='1.2.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.namespace' version='1.2.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.resource' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.startlevel' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.startlevel.dto' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.dto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.wiring' version='1.2.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework,org.osgi.resource' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.wiring.dto' version='1.3.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.dto,org.osgi.resource.dto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.resource' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.resource.dto' version='1.0.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.dto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.condition' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.condpermadmin' version='1.1.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.5.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.log.admin' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.service.log' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.packageadmin' version='1.2.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.permissionadmin' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.resolver' version='1.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.resource' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.startlevel' version='1.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.url' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.util.tracker' version='1.5.4'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.osgi' version='3.24.100.v20251215-1416'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-1' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.LogReaderService,org.eclipse.equinox.log.ExtendedLogReaderService' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.LoggerFactory,org.osgi.service.log.LogService,org.eclipse.equinox.log.ExtendedLogService' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-3' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.admin.LoggerAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-4' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.framework.log.FrameworkLog' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-5' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.user.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-6' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.instance.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-7' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.configuration.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-8' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.install.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-9' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='eclipse.home.location'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-10' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.environment.EnvironmentInfo' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-11' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.packageadmin.PackageAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-12' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.startlevel.StartLevel' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-13' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.permissionadmin.PermissionAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-14' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.condpermadmin.ConditionalPermissionAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-15' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.resolver.Resolver' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-16' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.debug.DebugOptions' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-17' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.urlconversion.URLConverter' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-18' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.localization.BundleLocalization' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-19' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.security.TrustEngine' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-20' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.signedcontent.SignedContentFactory' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.100.v20251215-1416-21' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.osgi.service.condition.Condition' type='List'/>
            <property name='osgi.condition.id' value='true'/>
          </properties>
        </provided>
        <provided namespace='osgi.serviceloader' name='org.osgi.framework.connect.ConnectFrameworkFactory' version='0.0.0'/>
        <provided namespace='osgi.serviceloader' name='org.osgi.framework.launch.FrameworkFactory' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(version=1.8)(|(osgi.ee=JavaSE)(osgi.ee=JavaSE/compact1)))'>
          <description>
            org.eclipse.osgi
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.source' range='[3.24.100.v20251215-1416,3.24.100.v20251215-1416]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi' version='3.24.100.v20251215-1416'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi; singleton:=true&#xA;Bundle-Version: 3.24.100.v20251215-1416
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.compatibility.state' version='1.3.0.v20251022-1724' singleton='false' generation='2'>
      <update id='org.eclipse.osgi.compatibility.state' range='[0.0.0,1.3.0.v20251022-1724)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.Bundle-Name' value='Equinox State and Resolver Compatibility Fragment'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.osgi.compatibility.state'/>
        <property name='maven-version' value='1.3.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state' version='1.3.0.v20251022-1724'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.compatibility.state' version='1.3.0.v20251022-1724'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi.compatibility.state' version='1.3.0.v20251022-1724'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.osgi' version='1.3.0.v20251022-1724'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='3.12.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.osgi.compatibility.state
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state.source' range='[1.3.0.v20251022-1724,1.3.0.v20251022-1724]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.compatibility.state' version='1.3.0.v20251022-1724'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.compatibility.state&#xA;Bundle-Version: 1.3.0.v20251022-1724&#xA;Fragment-Host: org.eclipse.osgi;bundle-version=&quot;3.12.0&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.util' version='3.7.400.v20250516-0916' singleton='false' generation='2'>
      <update id='org.eclipse.osgi.util' range='[0.0.0,3.7.400.v20250516-0916)' severity='0'/>
      <properties size='13'>
        <property name='df_LT.osgiUtilDes' value='OSGi Service Platform Release 4.2.0 Utility Classes'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.osgiUtil' value='OSGi Release 4.2.0 Utility Classes'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiUtil'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiUtilDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.osgi.util'/>
        <property name='maven-version' value='3.7.400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' version='3.7.400.v20250516-0916'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.util' version='3.7.400.v20250516-0916'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi.util' version='3.7.400.v20250516-0916'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.osgi.util.function' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.util.promise' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.util.measurement' range='[1.0.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.util.position' range='[1.0.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.util.xml' range='[1.0.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.osgi.util
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util.source' range='[3.7.400.v20250516-0916,3.7.400.v20250516-0916]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.util' version='3.7.400.v20250516-0916'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.util&#xA;Bundle-Version: 3.7.400.v20250516-0916
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.swt' version='3.133.0.v20260225-1014' generation='2'>
      <update id='org.eclipse.swt' range='[0.0.0,3.133.0.v20260225-1014)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Standard Widget Toolkit'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.swt'/>
        <property name='maven-version' value='3.133.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='20'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' version='3.133.0.v20260225-1014'/>
        <provided namespace='osgi.bundle' name='org.eclipse.swt' version='3.133.0.v20260225-1014'/>
        <provided namespace='java.package' name='org.eclipse.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.awt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.custom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.graphics' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.image' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.opengl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.printing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.program' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.widgets' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.swt' version='3.133.0.v20260225-1014'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86_64' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32)(!(org.eclipse.swt.buildtime=true)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.aarch64' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=win32)(osgi.ws=win32)(!(org.eclipse.swt.buildtime=true)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk)(!(org.eclipse.swt.buildtime=true)))
          </filter>
        </required>
        <required namespace='java.package' name='org.eclipse.swt.accessibility2' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa)(!(org.eclipse.swt.buildtime=true)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.source' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.ppc64le' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=ppc64le)(osgi.os=linux)(osgi.ws=gtk)(!(org.eclipse.swt.buildtime=true)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.aarch64' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=linux)(osgi.ws=gtk)(!(org.eclipse.swt.buildtime=true)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.aarch64' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=macosx)(osgi.ws=cocoa)(!(org.eclipse.swt.buildtime=true)))
          </filter>
        </required>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.swt
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.riscv64' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]'>
          <filter>
            (&amp;(osgi.arch=riscv64)(osgi.os=linux)(osgi.ws=gtk)(!(org.eclipse.swt.buildtime=true)))
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.swt' version='3.133.0.v20260225-1014'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.swt; singleton:=true&#xA;Bundle-Version: 3.133.0.v20260225-1014
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.swt.gtk.linux.x86_64' version='3.133.0.v20260225-1014'>
      <update id='org.eclipse.swt.gtk.linux.x86_64' range='[0.0.0,3.133.0.v20260225-1014)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.fragmentName' value='Standard Widget Toolkit for GTK on x86_64'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.swt.gtk.linux.x86_64'/>
        <property name='maven-version' value='3.133.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='27'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64' version='3.133.0.v20260225-1014'/>
        <provided namespace='osgi.bundle' name='org.eclipse.swt.gtk.linux.x86_64' version='3.133.0.v20260225-1014'/>
        <provided namespace='java.package' name='org.eclipse.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.awt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.custom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.graphics' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.opengl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.printing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.program' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.widgets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.image' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.accessibility.gtk' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.cairo' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.gtk' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.gtk3' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.gtk4' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.opengl.glx' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.swt.gtk.linux.x86_64' version='3.133.0.v20260225-1014'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.swt' version='3.133.0.v20260225-1014'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.128.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64.source' range='[3.133.0.v20260225-1014,3.133.0.v20260225-1014]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.swt.gtk.linux.x86_64' version='3.133.0.v20260225-1014'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.swt.gtk.linux.x86_64; singleton:=true&#xA;Bundle-Version: 3.133.0.v20260225-1014&#xA;Fragment-Host: org.eclipse.swt;bundle-version=&quot;[3.128.0,4.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.swt.svg' version='3.132.0.v20251202-1523' singleton='false' generation='2'>
      <update id='org.eclipse.swt.svg' range='[0.0.0,3.132.0.v20251202-1523)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.fragmentName' value='SWT SVG Rendering Support'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.swt.svg'/>
        <property name='maven-version' value='3.132.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.svg' version='3.132.0.v20251202-1523'/>
        <provided namespace='osgi.bundle' name='org.eclipse.swt.svg' version='3.132.0.v20251202-1523'/>
        <provided namespace='java.package' name='org.eclipse.swt.svg' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.swt.svg' version='3.132.0.v20251202-1523'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='eclipse.swt' name='org.eclipse.swt.svg_3.132.0.v20251202-1523-1' version='1.0.0'>
          <properties size='1'>
            <property name='image.format' value='svg'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.swt' version='3.132.0.v20251202-1523'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='java.package' name='com.github.weisj.jsvg.view' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='com.github.weisj.jsvg.parser' range='[2.0.0,3.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.aarch64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.riscv64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=riscv64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='java.package' name='com.github.weisj.jsvg' range='[2.0.0,3.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.aarch64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.aarch64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.svg.source' range='[3.132.0.v20251202-1523,3.132.0.v20251202-1523]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.swt.svg
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.ppc64le' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=ppc64le)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.swt.svg' version='3.132.0.v20251202-1523'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.swt.svg&#xA;Bundle-Version: 3.132.0.v20251202-1523&#xA;Fragment-Host: org.eclipse.swt
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.urischeme' version='1.3.600.v20251023-1158' generation='2'>
      <update id='org.eclipse.urischeme' range='[0.0.0,1.3.600.v20251023-1158)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.Plugin.name' value='Eclipse URI Scheme Handling'/>
        <property name='df_LT.Plugin.Providername' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.Providername'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.urischeme'/>
        <property name='maven-version' value='1.3.600-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.urischeme' version='1.3.600.v20251023-1158'/>
        <provided namespace='osgi.bundle' name='org.eclipse.urischeme' version='1.3.600.v20251023-1158'/>
        <provided namespace='java.package' name='org.eclipse.urischeme' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.urischeme' version='1.3.600.v20251023-1158'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.8.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.8.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='com.sun.jna' range='[5.8.0,6.0.0)'/>
        <required namespace='osgi.bundle' name='com.sun.jna.platform' range='[5.8.0,6.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.urischeme
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.urischeme.source' range='[1.3.600.v20251023-1158,1.3.600.v20251023-1158]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.urischeme' version='1.3.600.v20251023-1158'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.urischeme;singleton:=true&#xA;Bundle-Version: 1.3.600.v20251023-1158
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.cm' version='1.6.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.cm' range='[0.0.0,1.6.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.cm'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.cm Version 1.6.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.cm'/>
        <property name='maven-version' value='1.6.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.cm' version='1.6.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.cm' version='1.6.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.cm' version='1.6.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.cm.annotations' version='1.6.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.cm' version='1.6.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.cm
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.cm.source' range='[1.6.1.202109301733,1.6.1.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.cm' version='1.6.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.cm&#xA;Bundle-Version: 1.6.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.component' version='1.5.1.202212101352' singleton='false' generation='2'>
      <update id='org.osgi.service.component' range='[0.0.0,1.5.1.202212101352)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.component'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.component Version 1.5.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.component'/>
        <property name='maven-version' value='1.5.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.component' version='1.5.1.202212101352'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.component' version='1.5.1.202212101352'/>
        <provided namespace='java.package' name='org.osgi.service.component' version='1.5.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.component.propertytypes' version='1.5.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.runtime' version='1.5.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework,org.osgi.service.component.runtime.dto,org.osgi.util.promise' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.component.runtime.dto' version='1.5.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.dto,org.osgi.framework.dto' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.service.component' version='1.5.1.202212101352'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='java.package' name='org.osgi.dto' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.0.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.component
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.component.source' range='[1.5.1.202212101352,1.5.1.202212101352]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.component' version='1.5.1.202212101352'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.component&#xA;Bundle-Version: 1.5.1.202212101352
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.device' version='1.1.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.device' range='[0.0.0,1.1.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.device'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.device Version 1.1.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.device'/>
        <property name='maven-version' value='1.1.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.device' version='1.1.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.device' version='1.1.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.device' version='1.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.service.device' version='1.1.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.device
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.device.source' range='[1.1.1.202109301733,1.1.1.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.device' version='1.1.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.device&#xA;Bundle-Version: 1.1.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.event' version='1.4.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.event' range='[0.0.0,1.4.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.event'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.event Version 1.4.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.event'/>
        <property name='maven-version' value='1.4.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.event' version='1.4.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.event' version='1.4.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.event' version='1.4.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.event.annotations' version='1.4.1'/>
        <provided namespace='java.package' name='org.osgi.service.event.propertytypes' version='1.4.0'/>
        <provided namespace='osgi.identity' name='org.osgi.service.event' version='1.4.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.event
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.event.source' range='[1.4.1.202109301733,1.4.1.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.event' version='1.4.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.event&#xA;Bundle-Version: 1.4.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.metatype' version='1.4.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.metatype' range='[0.0.0,1.4.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.metatype'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.metatype Version 1.4.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.metatype'/>
        <property name='maven-version' value='1.4.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.metatype' version='1.4.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.metatype' version='1.4.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.metatype' version='1.4.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.service.metatype' version='1.4.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.metatype
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.metatype.source' range='[1.4.1.202109301733,1.4.1.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.metatype' version='1.4.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.metatype&#xA;Bundle-Version: 1.4.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.prefs' version='1.1.2.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.prefs' range='[0.0.0,1.1.2.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.prefs'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.prefs Version 1.1.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.prefs'/>
        <property name='maven-version' value='1.1.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.prefs' version='1.1.2.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.prefs' version='1.1.2.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.prefs' version='1.1.2'/>
        <provided namespace='osgi.identity' name='org.osgi.service.prefs' version='1.1.2.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.prefs
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.prefs.source' range='[1.1.2.202109301733,1.1.2.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.prefs' version='1.1.2.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.prefs&#xA;Bundle-Version: 1.1.2.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.provisioning' version='1.2.0.201505202024' singleton='false' generation='2'>
      <update id='org.osgi.service.provisioning' range='[0.0.0,1.2.0.201505202024)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.provisioning'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.provisioning Version 1.2.0.'/>
        <property name='org.eclipse.equinox.p2.provider' value='OSGi Alliance http://www.osgi.org/'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.provisioning'/>
        <property name='maven-version' value='1.2.0'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.provisioning' version='1.2.0.201505202024'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.provisioning' version='1.2.0.201505202024'/>
        <provided namespace='java.package' name='org.osgi.service.provisioning' version='1.2.0'/>
        <provided namespace='osgi.identity' name='org.osgi.service.provisioning' version='1.2.0.201505202024'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.2))'>
          <description>
            org.osgi.service.provisioning
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.provisioning.source' range='[1.2.0.201505202024,1.2.0.201505202024]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.provisioning' version='1.2.0.201505202024'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.provisioning&#xA;Bundle-Version: 1.2.0.201505202024
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.upnp' version='1.2.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.upnp' range='[0.0.0,1.2.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.upnp'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.upnp Version 1.2.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.upnp'/>
        <property name='maven-version' value='1.2.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.upnp' version='1.2.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.upnp' version='1.2.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.upnp' version='1.2.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.upnp' version='1.2.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.upnp
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.upnp.source' range='[1.2.1.202109301733,1.2.1.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.upnp' version='1.2.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.upnp&#xA;Bundle-Version: 1.2.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.useradmin' version='1.1.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.useradmin' range='[0.0.0,1.1.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.useradmin'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.useradmin Version 1.1.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.useradmin'/>
        <property name='maven-version' value='1.1.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.useradmin' version='1.1.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.useradmin' version='1.1.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.useradmin' version='1.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.service.useradmin' version='1.1.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.useradmin
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.useradmin.source' range='[1.1.1.202109301733,1.1.1.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.useradmin' version='1.1.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.useradmin&#xA;Bundle-Version: 1.1.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.wireadmin' version='1.0.2.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.wireadmin' range='[0.0.0,1.0.2.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.wireadmin'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.wireadmin Version 1.0.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.wireadmin'/>
        <property name='maven-version' value='1.0.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.wireadmin' version='1.0.2.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.wireadmin' version='1.0.2.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.wireadmin' version='1.0.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.service.wireadmin' version='1.0.2.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.wireadmin
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.wireadmin.source' range='[1.0.2.202109301733,1.0.2.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.wireadmin' version='1.0.2.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.wireadmin&#xA;Bundle-Version: 1.0.2.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.function' version='1.2.0.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.util.function' range='[0.0.0,1.2.0.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.function'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.function Version 1.2.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.function'/>
        <property name='maven-version' value='1.2.0'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.function' version='1.2.0.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.function' version='1.2.0.202109301733'/>
        <provided namespace='java.package' name='org.osgi.util.function' version='1.2.0'/>
        <provided namespace='osgi.identity' name='org.osgi.util.function' version='1.2.0.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.util.function
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.function.source' range='[1.2.0.202109301733,1.2.0.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.function' version='1.2.0.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.function&#xA;Bundle-Version: 1.2.0.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.measurement' version='1.0.2.201802012109' singleton='false' generation='2'>
      <update id='org.osgi.util.measurement' range='[0.0.0,1.0.2.201802012109)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.measurement'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.measurement Version 1.0.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='OSGi Alliance https://www.osgi.org/'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.measurement'/>
        <property name='maven-version' value='1.0.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.measurement' version='1.0.2.201802012109'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.measurement' version='1.0.2.201802012109'/>
        <provided namespace='java.package' name='org.osgi.util.measurement' version='1.0.2'/>
        <provided namespace='osgi.identity' name='org.osgi.util.measurement' version='1.0.2.201802012109'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.osgi.util.measurement
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.measurement.source' range='[1.0.2.201802012109,1.0.2.201802012109]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.measurement' version='1.0.2.201802012109'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.measurement&#xA;Bundle-Version: 1.0.2.201802012109
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.position' version='1.0.1.201505202026' singleton='false' generation='2'>
      <update id='org.osgi.util.position' range='[0.0.0,1.0.1.201505202026)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.position'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.position Version 1.0.1.'/>
        <property name='org.eclipse.equinox.p2.provider' value='OSGi Alliance http://www.osgi.org/'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.position'/>
        <property name='maven-version' value='1.0.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.position' version='1.0.1.201505202026'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.position' version='1.0.1.201505202026'/>
        <provided namespace='java.package' name='org.osgi.util.position' version='1.0.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.util.measurement' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.util.position' version='1.0.1.201505202026'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.util.measurement' range='[1.0.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.2))'>
          <description>
            org.osgi.util.position
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.position.source' range='[1.0.1.201505202026,1.0.1.201505202026]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.position' version='1.0.1.201505202026'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.position&#xA;Bundle-Version: 1.0.1.201505202026
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.promise' version='1.3.0.202212101352' singleton='false' generation='2'>
      <update id='org.osgi.util.promise' range='[0.0.0,1.3.0.202212101352)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.promise'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.promise Version 1.3.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.promise'/>
        <property name='maven-version' value='1.3.0'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.promise' version='1.3.0.202212101352'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.promise' version='1.3.0.202212101352'/>
        <provided namespace='java.package' name='org.osgi.util.promise' version='1.3.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.util.function' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.util.promise' version='1.3.0.202212101352'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.util.function' range='[1.1.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.util.promise
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.promise.source' range='[1.3.0.202212101352,1.3.0.202212101352]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.promise' version='1.3.0.202212101352'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.promise&#xA;Bundle-Version: 1.3.0.202212101352
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.xml' version='1.0.2.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.util.xml' range='[0.0.0,1.0.2.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.xml'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.xml Version 1.0.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.xml'/>
        <property name='maven-version' value='1.0.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.xml' version='1.0.2.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.xml' version='1.0.2.202109301733'/>
        <provided namespace='java.package' name='org.osgi.util.xml' version='1.0.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.parsers,org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.util.xml' version='1.0.2.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.util.xml
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.xml.source' range='[1.0.2.202109301733,1.0.2.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.xml' version='1.0.2.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.xml&#xA;Bundle-Version: 1.0.2.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.org.eclipse.update.feature.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            uninstallFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
          <instruction key='install'>
            installFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.osgi.bundle.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);
          </instruction>
          <instruction key='unconfigure'>

          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.source.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            removeSourceBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            addSourceBundle(bundle:${artifact})
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.apache.felix.scr' version='1.0.0.202605062350' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.apache.felix.scr' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.apache.felix.scr' version='1.0.0.202605062350'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.apache.felix.scr' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.core.runtime' version='1.0.0.202605062350' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.core.runtime' version='1.0.0.202605062350'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.equinox.common' version='1.0.0.202605062350' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.common' version='1.0.0.202605062350'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.equinox.event' version='1.0.0.202605062350' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.event' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.event' version='1.0.0.202605062350'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.event' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.equinox.simpleconfigurator' version='1.0.0.202605062350' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.simpleconfigurator' version='1.0.0.202605062350'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:1);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher' version='1.7.100.v20251111-0406' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='1.7.100.v20251111-0406'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' version='1.7.100.v20251111-0406'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='1.7.100.v20251111-0406'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:-startup);addProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:-startup);removeProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.1500.v20250801-0854' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='1.2.1500.v20250801-0854'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.1500.v20250801-0854'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='1.2.1500.v20250801-0854'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:--launcher.library);addProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:--launcher.library);removeProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinguseradmin.application' version='1.0.0.202605062350'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinguseradmin.application' version='1.0.0.202605062350'/>
      </provides>
      <requires size='13'>
        <required namespace='org.eclipse.equinox.p2.iu' name='useradmin.executable.cocoa.macosx.x86_64.eclipse' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinguseradmin.executable.win32.win32.x86_64' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='useradmin.executable.gtk.linux.x86_64.eclipse' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinguseradmin.executable.cocoa.macosx.x86_64' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='useradmin.executable.gtk.linux.x86_64' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='useradmin.executable.win32.win32.x86_64.eclipse' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='useradmin.executable.win32.win32.x86_64' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.x86_64' range='[1.2.1500.v20250801-0854,1.2.1500.v20250801-0854]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinguseradmin.executable.gtk.linux.x86_64' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='useradmin.executable.cocoa.macosx.x86_64' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.win32.win32.x86_64' range='[1.3.0.v20260203-2149,1.3.0.v20260203-2149]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.cocoa.macosx.x86_64' range='[1.2.1400.v20250801-0854,1.2.1400.v20250801-0854]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' range='[1.7.100.v20251111-0406,1.7.100.v20251111-0406]'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='toolinguseradmin.config.gtk.linux.x86_64' version='1.0.0.202605062350' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinguseradmin.config.gtk.linux.x86_64' version='1.0.0.202605062350'/>
        <provided namespace='toolinguseradmin' name='useradmin.config' version='1.0.0.202605062350'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            setProgramProperty(propName:eclipse.product,propValue:io.github.kkusylabs.useradmin.client.branding.product);setProgramProperty(propName:eclipse.application,propValue:org.eclipse.e4.ui.workbench.swt.E4Application);
          </instruction>
          <instruction key='unconfigure'>
            setProgramProperty(propName:eclipse.product,propValue:);setProgramProperty(propName:eclipse.application,propValue:);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinguseradmin.configuration' version='1.0.0.202605062350'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinguseradmin.configuration' version='1.0.0.202605062350'/>
      </provides>
      <requires size='19'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.equinox.simpleconfigurator' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.equinox.event' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.core.runtime' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.apache.felix.scr' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.common' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.event' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.apache.felix.scr' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.equinox.common' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinguseradmin.config.win32.win32.x86_64' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinguseradmin.ini.cocoa.macosx.x86_64' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.common' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinguseradmin.config.cocoa.macosx.x86_64' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.core.runtime' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.simpleconfigurator' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.core.runtime' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.apache.felix.scr' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinguseradmin.config.gtk.linux.x86_64' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.event' range='[1.0.0.202605062350,1.0.0.202605062350]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='toolinguseradmin.executable.gtk.linux.x86_64' version='1.0.0.202605062350' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='useradmin.executable.gtk.linux.x86_64' range='[1.0.0.202605062350,1.0.0.202605062350]'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinguseradmin.executable.gtk.linux.x86_64' version='1.0.0.202605062350'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='useradmin.executable.gtk.linux.x86_64' range='[1.0.0.202605062350,1.0.0.202605062350]'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder}); chmod(targetDir:${installFolder}, targetFile:eclipse, permissions:755);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='useradmin' version='1.0.0.202605062350'>
      <update id='useradmin' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='User Admin System'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='useradmin' version='1.0.0.202605062350'/>
      </provides>
      <requires size='8'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.rcp.feature.group' range='4.39.0.v20260225-1014'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(useradmin.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinguseradmin.application' range='[1.0.0.202605062350,1.0.0.202605062350]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='io.github.kkusylabs.useradmin.client.feature.feature.group' range='1.0.0.202605062350'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(useradmin.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinguseradmin.configuration' range='[1.0.0.202605062350,1.0.0.202605062350]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='osgi.ee' name='JavaSE' range='0.0.0'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
    </unit>
    <unit id='useradmin.executable.gtk.linux.x86_64' version='1.0.0.202605062350'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='useradmin.executable.gtk.linux.x86_64' version='1.0.0.202605062350'/>
        <provided namespace='toolinguseradmin' name='useradmin.executable' version='1.0.0.202605062350'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='useradmin.executable.gtk.linux.x86_64' version='1.0.0.202605062350'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='useradmin.executable.gtk.linux.x86_64.eclipse' version='1.0.0.202605062350' singleton='false'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='useradmin.executable.gtk.linux.x86_64.eclipse' version='1.0.0.202605062350'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            setLauncherName(name:eclipse)
          </instruction>
          <instruction key='unconfigure'>
            setLauncherName()
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='114'>
    <iuProperties id='io.github.kkusylabs.useradmin.client.feature.feature.group' version='1.0.0.202605062350'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.e4.rcp.feature.group' version='4.39.0.v20260225-1014'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='useradmin' version='1.0.0.202605062350'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='useradmin.executable.gtk.linux.x86_64' version='1.0.0.202605062350'>
      <properties size='1'>
        <property name='unzipped|@artifact|C:\Users\kkusy\IdeaProjects\user-admin-system\rcp-client\io.github.kkusylabs.useradmin.client.product\target\products\useradmin\linux\gtk\x86_64' value='C:\Users\kkusy\IdeaProjects\user-admin-system\rcp-client\io.github.kkusylabs.useradmin.client.product\target\products\useradmin\linux\gtk\x86_64\eclipse|'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
